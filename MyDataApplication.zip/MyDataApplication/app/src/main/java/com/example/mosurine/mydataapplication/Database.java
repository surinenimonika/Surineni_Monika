package com.example.mosurine.mydataapplication;

import android.content.ContentValues;
import android.content.Context;
import android.database.DatabaseErrorHandler;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class Database extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION=1;
    private static final String DATABASE_NAME = "Database";
    private static final String TABLE_DATA = "data";
    private static final String KEY_ID = "id";
    private static final String KEY_NAME = "name";
    private static final String KEY_PASSWORD = "password";
    private static final String KEY_MAILID = "mailId";
    private static final String KEY_MOBILENO="mobileNo";

    public Database(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String CREATE_DATA_TABLE = "CREATE TABLE " + TABLE_DATA + "("
                + KEY_ID + " INTEGER PRIMARY KEY," + KEY_NAME + " TEXT," + KEY_PASSWORD + " TEXT,"
                + KEY_MAILID + " TEXT," + KEY_MOBILENO + " TEXT" + ")";
        db.execSQL(CREATE_DATA_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {

        db.execSQL("DROP TABLE IF EXISTS " + TABLE_DATA);

        onCreate(db);
    }

    void addData(Data data) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, data.getName());
        values.put(KEY_PASSWORD, data.getPassword());
        values.put(KEY_MAILID,data.getMailId());
        values.put(KEY_MOBILENO, data.getMobileNo());


        db.insert(TABLE_DATA, null, values);

        db.close();
    }

    public int updateContact(Data data) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(KEY_NAME, data.getName());
        values.put(KEY_PASSWORD, data.getPassword());
        values.put(KEY_MAILID,data.getMailId());
        values.put(KEY_MOBILENO, data.getMobileNo());


        return db.update(TABLE_DATA, values, KEY_ID + " = ?",
                new String[] { String.valueOf(data.getId()) });
    }

}
