package com.example.mosurine.mydataapplication;

public class Data {

    int id;
    String name;
    String password;
    String mailId;
    String mobileNo;

    public Data()
    {

    }

    public Data(String name, String password, String mailId, String mobileNo) {
        this.id=id;
        this.name = name;
        this.password = password;
        this.mailId = mailId;
        this.mobileNo = mobileNo;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getMailId() {
        return mailId;
    }

    public void setMailId(String mailId) {
        this.mailId = mailId;
    }

    public String getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(String mobileNo) {
        this.mobileNo = mobileNo;
    }
}
