package com.example.mosurine.mydataapplication;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ListView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ListView listView = findViewById(R.id.listView);

        ArrayList<Data> dataDetails = new ArrayList<Data>();

        DataArrayAdapter adapter = new DataArrayAdapter(this,dataDetails);
        listView.setAdapter(adapter);

        Database database = new Database(this);

        database.addData(new Data("xyz","aaxaxn","oweriwrf@gmail.com","9876543210"));
        database.addData(new Data("abvnbn","gfhf","fghfb@gmail.com","9876543210"));


    }
}
