package com.cg.example.beans;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class FeedBack
{
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	
	
	@ManyToOne(cascade = CascadeType.ALL)
	private Customer customer;
	
	private String comment;
	
	private int rating;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	
	public Customer getCustomer() {
		return customer;
	}

	public void setCustomer(Customer customer) {
		this.customer = customer;
	}

	public String getComment() {
		return comment;
	}

	public void setComment(String comment) {
		this.comment = comment;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	@Override
	public String toString() {
		return "FeedBack [id=" + id + ", customer=" + customer + ", comment=" + comment + ", rating=" + rating + "]";
	}

	public FeedBack(int id, Customer customer, String comment, int rating) {
		super();
		this.id = id;
		this.customer = customer;
		this.comment = comment;
		this.rating = rating;
	}

	public FeedBack() {
		super();
		
	}

	
	
	
}
