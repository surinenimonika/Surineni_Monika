package com.cg.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.example.beans.Merchant;
import com.cg.example.service.MerchantService;

@RestController
public class MerchantController {
	
	@Autowired
	private MerchantService service;

	@RequestMapping(value ="/merchantActions/signUp" ,  method = RequestMethod.POST)
	public Merchant signUp(@RequestBody Merchant merchant)
	{
		return service.merchantSignUp(merchant);
	}
	
	@RequestMapping(value = "/merchantActions/login",  method = RequestMethod.POST)
	public Merchant login(@RequestBody Merchant merchant) {
		return service.findMerchant(merchant);
		
	}
	
	public MerchantService getService() {
		return service;
	}

	public void setService(MerchantService service) {
		this.service = service;
	}
	
	
	
	
	
}
