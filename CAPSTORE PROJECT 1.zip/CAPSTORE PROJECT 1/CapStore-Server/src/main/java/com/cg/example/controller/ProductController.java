package com.cg.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.example.beans.Product;
import com.cg.example.service.IProduct;

@RestController
public class ProductController {
	@Autowired
	private IProduct productservice;
	@RequestMapping(value="/actions/sortingproducts", method= RequestMethod.POST)
	public Product sortedProductList(@RequestBody Product product)
	{
		return (Product) productservice.productsByPrice(product.getCategory());
	}

}
