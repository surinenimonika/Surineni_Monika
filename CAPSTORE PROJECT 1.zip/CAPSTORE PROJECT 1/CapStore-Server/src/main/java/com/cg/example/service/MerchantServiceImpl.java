package com.cg.example.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.example.beans.Merchant;
import com.cg.example.exception.MerchantAccountException;
import com.cg.example.repo.MerchantRepo;

public class MerchantServiceImpl implements MerchantService {

	@Autowired
	private MerchantRepo repo;
	
	
	@Override
	public Merchant merchantSignUp(Merchant merchant) {
		
		return repo.save(merchant);
	}
	
	@Override
	public Merchant findMerchant(Merchant merchant) {
		Merchant temp = repo.getOne(merchant.getId());
		if(temp.getPassword()==merchant.getPassword()) {
			return temp;	
		}
		else
			throw new MerchantAccountException("invalid login id or password");
	}


	public MerchantRepo getRepo() {
		return repo;
	}


	public void setRepo(MerchantRepo repo) {
		this.repo = repo;
	}




	

}
