package com.cg.example.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.example.beans.Product;
import com.cg.example.repo.ProductRepo;

public class ProductService implements IProduct {

	@Autowired
	ProductRepo productrepo;
	@Override
	public List<Product> productsByPrice(String category) {
		// TODO Auto-generated method stub
		return productrepo.productsByPrice(category);
	}

}
