package com.cg.example.service;

import java.util.List;

import com.cg.example.beans.Product;
import com.cg.example.beans.WishList;

public interface IWishList {
	public WishList addToWishList(WishList wishlist);
	public List<Product> viewWishList(int custId);

}
