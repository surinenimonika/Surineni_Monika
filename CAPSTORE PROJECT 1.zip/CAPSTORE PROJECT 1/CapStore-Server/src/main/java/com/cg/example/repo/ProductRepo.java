package com.cg.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import com.cg.example.beans.Product;


public interface ProductRepo extends JpaRepository<Product, Integer> {
	@Query(value="SELECT products FROM Product products WHERE products.category=?1 ORDER BY cost")
	public List<Product> productsByPrice(String category);

}
