package com.cg.example.exception;

public class MerchantAccountException extends RuntimeException {

	public MerchantAccountException(String string) {
	super(string);	
	}

	
	
}
