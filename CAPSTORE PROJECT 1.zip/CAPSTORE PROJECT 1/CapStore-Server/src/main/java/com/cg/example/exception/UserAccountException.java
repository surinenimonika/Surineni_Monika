package com.cg.example.exception;

public class UserAccountException extends RuntimeException {

	public UserAccountException(String string) {
		super(string);
	}

	
	
	
}
