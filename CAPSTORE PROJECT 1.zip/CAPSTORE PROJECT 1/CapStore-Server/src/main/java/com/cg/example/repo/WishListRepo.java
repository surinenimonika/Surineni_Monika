package com.cg.example.repo;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cg.example.beans.WishList;

public interface WishListRepo extends JpaRepository<WishList, Integer>{
	
	
	
}
