package com.cg.example.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;

import com.cg.example.beans.Product;
import com.cg.example.beans.WishList;
import com.cg.example.repo.WishListRepo;

public class WishListImpl implements IWishList{
    @Autowired
    WishListRepo wishlistrepo;
	@Override
	public WishList addToWishList(WishList wishlist) {
		// TODO Auto-generated method stub
		
		return wishlistrepo.save(wishlist) ;
	}

	@Override
	public List<Product> viewWishList(int custId) {
		// TODO Auto-generated method stub
		return wishlistrepo.getOne(custId).getProduct();
	}

}
