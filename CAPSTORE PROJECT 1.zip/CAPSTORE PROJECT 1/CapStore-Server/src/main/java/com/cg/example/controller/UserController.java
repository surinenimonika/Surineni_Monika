package com.cg.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.example.beans.Customer;
import com.cg.example.service.UserService;

@RestController
public class UserController {
	
@Autowired
private UserService service;


@RequestMapping(value ="/userActions/signUp" , method = RequestMethod.POST)	
public Customer signUp(@RequestBody Customer customer)
{
	
	return service.userSignUp(customer);
}

@RequestMapping(value = "/userActions/login" , method = RequestMethod.POST)
public Customer login(@RequestBody Customer customer)
{
	return service.findUser(customer);
}

public UserService getService() {
	return service;
}


public void setService(UserService service) {
	this.service = service;
}
}
