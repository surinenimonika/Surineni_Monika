package com.cg.example.service;

import com.cg.example.beans.Customer;
import com.cg.example.exception.UserAccountException;
import com.cg.example.repo.UserRepo;

public class UserServiceImpl implements UserService {

	private UserRepo repo;
	
	@Override
	public Customer userSignUp(Customer customer) {

		return repo.save(customer);
	}

	public UserRepo getRepo() {
		return repo;
	}

	public void setRepo(UserRepo repo) {
		this.repo = repo;
	}

	@Override
	public Customer findUser(Customer customer) {
		Customer temp = repo.getOne(customer.getId());
		
			if(temp.getPassword()==customer.getPassword()) 
				return temp;	
			else
			throw new UserAccountException("invalid login id or password");
		
	}

}
