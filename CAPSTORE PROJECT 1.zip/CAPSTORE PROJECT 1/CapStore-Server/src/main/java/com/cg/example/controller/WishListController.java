package com.cg.example.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.cg.example.beans.WishList;
import com.cg.example.service.IWishList;

@RestController
public class WishListController {
	@Autowired
	private IWishList wishlistservice;
	
	@RequestMapping(value="/actions/addToWishList", method= RequestMethod.POST)
	public WishList addToWishList(@RequestBody WishList wishlist)
	{
		
		return wishlistservice.addToWishList(wishlist);
		
	}
	
	

}
