package com.cg.example.service;

import java.util.List;

import com.cg.example.beans.Product;

public interface IProduct {
	
	public List<Product> productsByPrice(String category);

}
