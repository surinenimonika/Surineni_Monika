package com.cg.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.client.RestTemplate;

import com.cg.example.beans.Customer;
import com.cg.example.beans.WishList;
@Controller
public class WishListController {
	
	@RequestMapping(value="/addToWishList" )
	public WishList addToWishList(@RequestBody WishList wishlist)
	{
		RestTemplate send = new RestTemplate();
		
		return send.postForObject("http://localhost:8081/actions/addToWishList",wishlist,WishList.class);
	}
	
	

}
