package com.cg.example.beans;

import java.util.List;


public class Product 
{
  
  private int id;
 
  private String name;
  
  private String description;
  
  private float cost;
  
  private String status;
  
  private int quantity;
  
  private String imgLink;
  
  private float averageRating;
  
 
  private Merchant merchant;
  
 
  private String category;
  
 
  private List<FeedBack> feedback;

public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public String getDescription() {
	return description;
}

public void setDescription(String description) {
	this.description = description;
}

public float getCost() {
	return cost;
}

public void setCost(float cost) {
	this.cost = cost;
}

public String getStatus() {
	return status;
}

public void setStatus(String status) {
	this.status = status;
}

public int getQuantity() {
	return quantity;
}

public void setQuantity(int quantity) {
	this.quantity = quantity;
}

public String getImgLink() {
	return imgLink;
}

public void setImgLink(String imgLink) {
	this.imgLink = imgLink;
}

public float getAverageRating() {
	return averageRating;
}

public void setAverageRating(float averageRating) {
	this.averageRating = averageRating;
}

public Merchant getMerchant() {
	return merchant;
}

public void setMerchant(Merchant merchant) {
	this.merchant = merchant;
}

public String getCategory() {
	return category;
}

public void setCategory(String category) {
	this.category = category;
}

public List<FeedBack> getFeedback() {
	return feedback;
}

public void setFeedback(List<FeedBack> feedback) {
	this.feedback = feedback;
}

public Product(int id, String name, String description, float cost, String status, int quantity, String imgLink,
		float averageRating, Merchant merchant, String category, List<FeedBack> feedback) {
	super();
	this.id = id;
	this.name = name;
	this.description = description;
	this.cost = cost;
	this.status = status;
	this.quantity = quantity;
	this.imgLink = imgLink;
	this.averageRating = averageRating;
	this.merchant = merchant;
	this.category = category;
	this.feedback = feedback;
}

@Override
public String toString() {
	return "Product [id=" + id + ", name=" + name + ", description=" + description + ", cost=" + cost + ", status="
			+ status + ", quantity=" + quantity + ", imgLink=" + imgLink + ", averageRating=" + averageRating
			+ ", merchant=" + merchant + ", category=" + category + ", feedback=" + feedback + "]";
}

public Product() {
	super();
	
}


  
  
}