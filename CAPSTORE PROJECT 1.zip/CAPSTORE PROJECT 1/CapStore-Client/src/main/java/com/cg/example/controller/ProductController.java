package com.cg.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.client.RestTemplate;

import com.cg.example.beans.Product;

@Controller
public class ProductController {
	@RequestMapping(value="/sortingproducts")
	public Product sortedProuctList(@RequestBody Product product)
	{
RestTemplate send = new RestTemplate();
		
		return send.postForObject("http://localhost:8081/actions/sortingproducts",product,Product.class);
		
	}

}
