package com.cg.example.controller;

import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.client.RestTemplate;

import com.cg.example.beans.Customer;

@RestController("/user")
public class UserController {
	



@RequestMapping("/signUp")	
public Customer signUp(@RequestBody Customer customer)
{
	
	RestTemplate send = new RestTemplate();
	
	return send.postForObject("http://localhost:8081/userActions/signUp",customer,Customer.class);
}

@RequestMapping(value = "/login", method = RequestMethod.POST)
public Customer login(@RequestParam int id, @RequestParam String password)
{
	Customer customer = new Customer();
	customer.setId(id);
	customer.setPassword(password);
	
	RestTemplate send = new RestTemplate();
	
	return send.postForObject("http://localhost:8081/userActions/login",customer,Customer.class);
	
}



}
