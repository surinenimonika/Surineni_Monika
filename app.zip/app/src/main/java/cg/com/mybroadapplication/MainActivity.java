package cg.com.mybroadapplication;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity{
    Boolean isNetworkAvailable;
  /*  // Used to load the 'native-lib' library on application startup.
    static {
        System.loadLibrary("native-lib");
    }*/

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

       Button button=(Button)findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View view) {
                isConnection();
                Intent intent = new Intent(MainActivity.this, MyBroadcastReceiver.class);
                intent.setAction("cg.com.mybroadapplication.MyBroadcastReceiver");
                sendBroadcast(intent);
            }
             }
                );

    }
    public void isConnection()
    {
        ConnectivityManager cm = (ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo nInfo = cm.getActiveNetworkInfo();
        NetworkInfo netInfo = cm.getNetworkInfo(ConnectivityManager.TYPE_MOBILE);
       /*if(netInfo.isConnected())
       {
           Log.d("Network","isavailable");
       }else
       {
           Log.d("Network","not isavailable");
       }*/

        if(netInfo!=null && netInfo.isAvailable() && netInfo.isConnected()||((nInfo!=null && nInfo.isAvailable()&& nInfo.isConnected())))
        {
            isNetworkAvailable =true;

            Log.i("names","Network available");
        }else
        {
            isNetworkAvailable=false;
            Log.i("names","Network Not available");
        }
    }


    /**
     * A native method that is implemented by the 'native-lib' native library,
     * which is packaged with this application.
     */
   // public native String stringFromJNI();
}
