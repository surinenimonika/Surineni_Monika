package com.cg.sqlitedemo

import android.content.ContentValues
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.Button
import android.widget.EditText
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity(),View.OnClickListener {
    override fun onClick(p0: View?) {
        if(p0 == button){
        dpHelper.insert(name!!.text.toString(),age!!.text.toString(),salary!!.text.toString())
        dpHelper.query()}
        if(p0 == button3){
            var intent = Intent(this,ViewAllActivity::class.java)
           // var list =dpHelper.retriveAll()

            startActivity(intent)
        }
        if(p0 == button2) {
            var updateValues = ContentValues()
            updateValues.put("${DataBaseHelper.getCol_age()}", "${(updateAge!!.text.toString()).toInt()}")
            dpHelper.update(updateValues, "${DataBaseHelper.getCol_name()} = +'${name!!.text.toString()}'", null)
            bean = dpHelper.query()
            Log.d("tag","${bean.emp_age}")
        }

    }

    var name:EditText?=null
    var age:EditText?=null
    var updateAge:EditText?=null
    var salary:EditText?=null
    var Insert:Button?=null
    var update:Button?=null
    var viewAll:Button?=null
    var dpHelper = DataBaseHelper(this);
    var bean = EmployeeBean()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        name = findViewById(R.id.editText) as EditText?
        age = findViewById(R.id.editText3) as EditText?
        updateAge = findViewById(R.id.editText5) as EditText?
        salary = findViewById(R.id.editText4) as EditText?
        Insert = findViewById(R.id.button) as Button?
        update = findViewById(R.id.button2) as Button?
        viewAll = findViewById(R.id.button3) as Button?
        viewAll!!.setOnClickListener(this)
        dpHelper.open()
        Insert!!.setOnClickListener(this)
        update!!.setOnClickListener(this)

        dpHelper.delete("name = 'priya'",null)
       // dpHelper.close()
    }
}
