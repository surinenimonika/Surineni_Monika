package com.cg.sqlitedemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by trainee on 7/23/2018.
 */

public class DataBaseHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "emp.db";
    public static String DATABASE_TABLE = "emp1";
    private SQLiteDatabase database;
    EmployeeBean bean = new EmployeeBean();




    public static String col_id = "id";
    private static String col_name = "name";
    private static String col_age = "age";
    private static String col_sal = "salary";
    private String[] columns = {col_id,col_name,col_age,col_sal};
    private String selection;
    private String[] selectionArgs;
    private String groupBy;
    private String having;
    private String orderBy;
    public Context context;

    private static final String DATABASE_CREATE = "create table if not exists " + DATABASE_TABLE +
            " (" + col_id + " integer primary key autoincrement, " + col_name +
            " varchar(15)," + col_age + " integer, " + col_sal + " integer);";
    public DataBaseHelper(Context context){

        super(context,DATABASE_NAME,null,DATABASE_VERSION);
        this.context = context;

    }
    public static String getCol_name() {
        return col_name;
    }

    public static String getCol_age() {
        return col_age;
    }

    public static String getCol_sal() {
        return col_sal;
    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(DATABASE_CREATE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(DATABASE_NAME);
        onCreate(sqLiteDatabase);

    }
    public void open(){
        database = this.getWritableDatabase();
        Log.d("SQLITE DEMO","Data base opened");
    }
    public void close(){
        database.close();
        Log.d("SQLITE DEMO","Data base closed");
    }
    public long insert(String name,String age,String salary){
        ContentValues initialvalues = new ContentValues();
        initialvalues.put(col_name,name);
        initialvalues.put(col_age,Integer.parseInt(age));
        initialvalues.put(col_sal,Integer.parseInt(salary));
        long returnValue = database.insert(DATABASE_TABLE,null,initialvalues);
        if(returnValue>0){
            Log.d("SQLITE DEMO","VALUE INSERTED");
        }else
            Log.d("SQLITE DEMO","VALUE NOT INSERTED");
        return returnValue;
    }
    public int update(ContentValues values,String whereClause,String whereArgs[]){
        int returnValue = database.update(DATABASE_TABLE,values,whereClause,whereArgs);
        if(returnValue > 0)
            Log.d("SQLITE DEMO","VALUE UPDATED");
        else
            Log.d("SQLITE DEMO","VALUE NOT UPGRADED");
        return returnValue;
    }
    public int delete(String whereClause,String whereArgs[]){
        int returnValues = database.delete(DATABASE_TABLE,whereClause,whereArgs);
        if(returnValues > 0)
            Log.d("SQLITE DEMO","VALUE DELETED");
        else
            Log.d("SQLITE DEMO","VALUE NOT DELETED");
        return returnValues;
    }
    public Map<Integer,EmployeeBean> retriveAll(){
        Map<Integer,EmployeeBean> map = new HashMap<Integer, EmployeeBean>();
        ///database = this.getReadableDatabase();
        Cursor cursor1 = database.query(DATABASE_TABLE, columns, selection, selectionArgs, groupBy, having, orderBy);
        if(cursor1.moveToFirst()){
            do{
                EmployeeBean bean = new EmployeeBean();
                bean.setEmp_id(Integer.parseInt(cursor1.getString(cursor1.getColumnIndex(col_id))));
                bean.setEmp_name(cursor1.getString(cursor1.getColumnIndex(col_name)));
                bean.setEmp_age(Integer.parseInt(cursor1.getString(cursor1.getColumnIndex(col_age))));
                bean.setEmp_salary(Integer.parseInt(cursor1.getString(cursor1.getColumnIndex(col_sal))));
                map.put(bean.getEmp_id(),bean);
                Toast.makeText(context,map.values().toString(),Toast.LENGTH_LONG).show();
            }while (cursor1.moveToNext());

        }
        Log.d("SQLiteDemo-retriveall()", "Record count : ");
        return map;

    }
    public EmployeeBean query() {
        Cursor cursor = database.query(DATABASE_TABLE, columns, selection, selectionArgs, groupBy, having, orderBy);
        Log.d("SQLiteDemo-query()", "Record count : " + cursor.getCount());
        if (cursor.moveToLast()) {
             {
                Log.d("SQLiteDemo-query()", "Name : " + cursor.getString(cursor.getColumnIndex(col_name)) + " Age : "
                        + cursor.getString(cursor.getColumnIndex(col_age)) + " SALARY :" +cursor.getString(cursor.getColumnIndex(col_sal)));
                bean.setEmp_id(Integer.parseInt(cursor.getString(cursor.getColumnIndex(col_id))));
                bean.setEmp_name(cursor.getString(cursor.getColumnIndex(col_name)));
                bean.setEmp_age(Integer.parseInt(cursor.getString(cursor.getColumnIndex(col_age))));
                bean.setEmp_salary(Integer.parseInt(cursor.getString(cursor.getColumnIndex(col_sal))));


            }

        }
        return bean;
    }
}
