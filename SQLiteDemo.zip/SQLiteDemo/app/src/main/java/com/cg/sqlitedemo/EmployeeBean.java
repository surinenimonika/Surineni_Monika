package com.cg.sqlitedemo;

/**
 * Created by trainee on 7/23/2018.
 */

public class EmployeeBean {
    private int emp_id;
    private String emp_name;
    private int emp_age;
    private int emp_salary;
    public EmployeeBean(Integer emp_id,String emp_name,Integer emp_age,Integer emp_salary){
        this.emp_age = emp_age;
        this.emp_id = emp_id;
        this.emp_name = emp_name;
        this.emp_salary = emp_salary;
    }
public EmployeeBean(){}
    public int getEmp_id() {
        return emp_id;
    }

    public void setEmp_id(int emp_id) {
        this.emp_id = emp_id;
    }

    public String getEmp_name() {
        return emp_name;
    }

    public void setEmp_name(String emp_name) {
        this.emp_name = emp_name;
    }

    @Override
    public String toString() {
        return "EmployeeBean{" +
                "emp_id=" + emp_id +
                ", emp_name='" + emp_name + '\'' +
                ", emp_age=" + emp_age +
                ", emp_salary=" + emp_salary +
                '}';
    }

    public int getEmp_age() {
        return emp_age;
    }

    public void setEmp_age(int emp_age) {
        this.emp_age = emp_age;
    }

    public int getEmp_salary() {
        return emp_salary;
    }

    public void setEmp_salary(int emp_salary) {
        this.emp_salary = emp_salary;
    }
}
