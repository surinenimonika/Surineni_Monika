package cg.com.bookmyshow;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;

public class Screen2Activity extends AppCompatActivity {
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {
        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    Intent intent= new Intent(getApplicationContext(),Screen1Activity.class);
                    startActivity(intent);
                    return true;
                case R.id.navigation_booking:

                {
                    Intent intentbooking = new Intent(getApplicationContext(), BookingHistoryActivity.class);
                    startActivity(intentbooking);
                    //mTextMessage.setText("Booking History");
                    return true;
                }
                case R.id.Help: {
                    Intent intenthelp = new Intent(getApplicationContext(), HelpActivity.class);
                    startActivity(intenthelp);
                    //mTextMessage.setText("Help");
                    return true;
                }
                case R.id.aboutUs:
                    Intent intentAbout = new Intent(getApplicationContext(), AboutUsActivity.class);
                    startActivity(intentAbout);
                    // mTextMessage.setText("About Us");
                    return true;
            }
            return false;
        }
    };

    TabLayout tabLayout;
    ViewPager viewPager;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen2);
DatabaseMovies movie = new DatabaseMovies(this);

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        TabLayout tabLayout;
        final ViewPager viewPager;


            tabLayout= findViewById(R.id.tabLayout);
            viewPager=findViewById(R.id.viewPager);

            tabLayout.addTab(tabLayout.newTab().setText("Movies"));
            tabLayout.addTab(tabLayout.newTab().setText("Cinemas"));


            tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

            final MyAdapterScreen2 adapter = new MyAdapterScreen2(this,getSupportFragmentManager(), tabLayout.getTabCount());
            viewPager.setAdapter(adapter);

            viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

            tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
                @Override
                public void onTabSelected(TabLayout.Tab tab) {

                    viewPager.setCurrentItem(tab.getPosition());

                }

                @Override
                public void onTabUnselected(TabLayout.Tab tab) {

                }

                @Override
                public void onTabReselected(TabLayout.Tab tab) {

                }
            });
            movie.open();
        movie.insert("RA.One (2D) (U)","Hindi","ActionDrama","2hrs 30min","SharukhKhan");
        movie.insert("Inside Out (2D)","English","Comedy","2hrs 30min","Vijay Devarkonda");
        movie.insert("Gudachari (2D) (U)","Telugu","Action","3hrs 10min","Adivi sesh");
        movie.insert("Gold (2D)","Hindi","Drama","2hrs 30min","Ranbir Kapoor");

        movie.insert("Infinity War (3D)","English","action","2hrs 30min","RoberDowney Junior");
        movie.insert("The Little Mermaid (2D)","English","Crime","3hrs 00min","Kamal Haasan");
        movie.insert("parmanu (2D)","Hindi","Drama","2hrs 30min","John Abraham");
        movie.insert("Satyameva Jayate (2D)","Hindi","Thriller","2hrs 45min","John Abraham");
        movie.insert("Pari (2D)","Hindi","Thriller","2hrs 20min","vicky Kaushal");
        movie.insert("ShatamanamBhavati","Hindi","Drama","2hrs 20min","Shashank Khaitan");
    }

}
