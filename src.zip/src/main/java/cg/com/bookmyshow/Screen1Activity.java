package cg.com.bookmyshow;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v7.app.AppCompatActivity;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.TextView;

import java.util.ArrayList;

public class Screen1Activity extends AppCompatActivity {

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    Intent intent= new Intent(getApplicationContext(),Screen1Activity.class);
                    startActivity(intent);
                    //mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_booking: {
                    Intent intentbooking = new Intent(getApplicationContext(), BookingHistoryActivity.class);
                    startActivity(intentbooking);
                    //mTextMessage.setText("Booking History");
                    return true;
                }
                case R.id.Help:
                {
                    Intent intenthelp = new Intent(getApplicationContext(), HelpActivity.class);
                    startActivity(intenthelp);
                    //mTextMessage.setText("Help");
                    return true;
                }
                case R.id.aboutUs:
                    Intent intentAbout = new Intent(getApplicationContext(), AboutUsActivity.class);
                    startActivity(intentAbout);
                   // mTextMessage.setText("About Us");
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_screen1);

       // mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
        final ListView list  = (ListView) findViewById(R.id.list);
        ArrayList<Screen1Info> data_array_list = new ArrayList<Screen1Info>();
        data_array_list.add(new Screen1Info("MOVIES"));
        data_array_list.add(new Screen1Info("ARTS & THEATRE"));
        data_array_list.add(new Screen1Info("SPORTS"));
        data_array_list.add(new Screen1Info("EVENTS"));
       final CustomAdapter adapt  = (CustomAdapter) new CustomAdapter(data_array_list, this) ;
        list.setAdapter(adapt);

        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {
                switch(i) {
                    case 0:
                        Intent intent = new Intent(getApplicationContext(), Screen2Activity.class);
                        list.getChildAt(i).setBackgroundColor(Color.GRAY);
                        startActivity(intent);
                        break;
                    case 1:
                        Intent intentArts = new Intent(getApplicationContext(), ArtsandTheatreActivity.class);
                        list.getChildAt(i).setBackgroundColor(Color.GRAY);
                        startActivity(intentArts);

                        break;
                    case 2:
                        Intent intentSports = new Intent(getApplicationContext(), SportsActivity.class);
                        list.getChildAt(i).setBackgroundColor(Color.GRAY);
                        startActivity(intentSports);


                        break;
                    case 3:
                        Intent intentEvents = new Intent(getApplicationContext(), EventsActivity.class);
                        list.getChildAt(i).setBackgroundColor(Color.GRAY);
                        startActivity(intentEvents);
                        break;
                }
            }
        });


}
    }


