package cg.com.bookmyshow

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.view.View

class HelpActivity : AppCompatActivity() {
    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                val intent = Intent(this, Screen1Activity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_booking -> {

                //mTextMessage.setText("Booking History");
                val intent: Intent = Intent(this, BookingHistoryActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.Help -> {
                val intent = Intent(this, HelpActivity::class.java)
                startActivity(intent)

                //mTextMessage.setText("Help");
                return@OnNavigationItemSelectedListener true
            }
            R.id.aboutUs ->
                // mTextMessage.setText("About Us");
            {
                val intentAbout = Intent(applicationContext, AboutUsActivity::class.java)
                startActivity(intentAbout)
                // mTextMessage.setText("About Us");
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_help)
        val navigation = findViewById<View>(R.id.navigation) as BottomNavigationView
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
    }
}
