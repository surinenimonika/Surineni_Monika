package cg.com.bookmyshow;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.MenuItem;
import android.widget.TextView;

public class TheatreScreen extends AppCompatActivity {



    TabLayout tabLayout;
    ViewPager viewPager;
    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    Intent intent= new Intent(getApplicationContext(),Screen1Activity.class);
                    startActivity(intent);
                    return true;
                case R.id.navigation_booking:

                {
                    Intent intentbooking = new Intent(getApplicationContext(), BookingHistoryActivity.class);
                    startActivity(intentbooking);
                    //mTextMessage.setText("Booking History");
                    return true;
                }
                case R.id.Help: {
                    Intent intenthelp = new Intent(getApplicationContext(), HelpActivity.class);
                    startActivity(intenthelp);
                    //mTextMessage.setText("Help");
                    return true;
                }
                case R.id.aboutUs:
                    Intent intentAbout = new Intent(getApplicationContext(), AboutUsActivity.class);
                    startActivity(intentAbout);
                    // mTextMessage.setText("About Us");
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theatre_screen);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);



        tabLayout = findViewById(R.id.tabLayout);
        viewPager = findViewById(R.id.viewPager);

        tabLayout.addTab(tabLayout.newTab().setText("ShowTimes"));
        tabLayout.addTab(tabLayout.newTab().setText("MoreInfo"));


        tabLayout.setTabGravity(TabLayout.GRAVITY_FILL);

        final MyAdapterScreen4 adapter = new MyAdapterScreen4(this, getSupportFragmentManager(), tabLayout.getTabCount());
        viewPager.setAdapter(adapter);

        viewPager.addOnPageChangeListener(new TabLayout.TabLayoutOnPageChangeListener(tabLayout));

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {

                viewPager.setCurrentItem(tab.getPosition());

            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });

    }
}