package cg.com.bookmyshow;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by trainee on 8/13/2018.
 */

public class DatabaseMovies extends SQLiteOpenHelper {

    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "movie.db";
    public static String DATABASE_TABLE = "Movie";
    private SQLiteDatabase database;

    public static String col_id = "movieId";
    private static String col_name = "movieName";
    private static String col_language = "movieLang";
    private static String col_genre = "movieGenre";
    private static String col_length = "movieLength";
    private static String col_actors = "movieActors";
    private String[] columns = {col_id,col_name,col_language,col_genre,col_length,col_actors};
    private String selection;
    private String[] selectionArgs;
    private String groupBy;
    private String having;
    private String orderBy;
    public Context context;

    private static final String DATABASE_CREATE = " create table if not exists " + DATABASE_TABLE +
            " (" + col_id + " integer primary key autoincrement, " + col_name +
            " varchar(15) UNIQUE," + col_language + " varchar(15)," +col_genre+ " varchar(15),"
            +col_length+" varchar(15),"+col_actors+" varchar(15));";
    public static String getCol_name() {
        return col_name;
    }

    public static String getcol_language() {
        return col_language;
    }
    public static String getcol_genre() {
        return col_genre;
    }
    public static String getcol_length() {
        return col_length;
    }
    public static String getcol_actors() {
        return col_actors;
    }


    public DatabaseMovies(Context context)
    {

        super(context,DATABASE_NAME,null,DATABASE_VERSION);
        this.context = context;

    }
    public void open()
    {

       database=this.getWritableDatabase();
        //database = context.getApplicationContext().openOrCreateDatabase("fsdf",10,DATABASE_NAME)
        Log.d("SQLITE DEMO","Data base opened");
    }
    public void close()
    {
        database.close();
        Log.d("SQLITE DEMO","Data base closed");
    }

        @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL(DATABASE_CREATE);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(DATABASE_NAME);
        onCreate(sqLiteDatabase);


    }

    public long insert(String name,String language,String genre,String length,String actors)
    {
        database=this.getWritableDatabase();
        ContentValues initialvalues = new ContentValues();
        initialvalues.put(col_name,name);
        initialvalues.put(col_language,language);
        initialvalues.put(col_genre,genre);
        initialvalues.put(col_length,length);
        initialvalues.put(col_actors,actors);
        long returnValue = database.insert(DATABASE_TABLE,null,initialvalues);
        if(returnValue>0){
            Log.d("sql",name);
            Log.d("SQLITE DEMO","VALUE INSERTED");
        }else
            Log.d("SQLITE DEMO","VALUE NOT INSERTED");
        return returnValue;
    }
   public Map<Integer,MovieDataModel> retriveAll()
    {
        Map<Integer,MovieDataModel> map = new HashMap<Integer, MovieDataModel>();
        database = this.getReadableDatabase();
        Cursor cursor1 = database.query(DATABASE_TABLE, columns, selection, selectionArgs, groupBy, having, orderBy);
        if(cursor1.moveToFirst()){
            do{
                MovieDataModel bean = new MovieDataModel();

                bean.setMovieId(Integer.parseInt(cursor1.getString(cursor1.getColumnIndex(col_id))));
                bean.setMovieName(cursor1.getString(cursor1.getColumnIndex(col_name)));
                bean.setLanguage(cursor1.getString(cursor1.getColumnIndex(col_language)));
                bean.setGenere(cursor1.getString(cursor1.getColumnIndex(col_genre)));
                bean.setLength(cursor1.getString(cursor1.getColumnIndex(col_length)));
                bean.setActors(cursor1.getString(cursor1.getColumnIndex(col_actors)));
                map.put(bean.getMovieId(),bean);

            }while (cursor1.moveToNext());

        }
        Log.d("SQLiteDemo-retriveall()", "Record count : ");
        return map;

    }


}
