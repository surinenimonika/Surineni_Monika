package cg.com.bookmyshow

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.support.v7.app.AlertDialog
import android.view.MenuItem
import android.view.View
import android.widget.*
import org.w3c.dom.Text
import java.util.*
import android.widget.Toast
import android.content.DialogInterface



class Screen7Activity : AppCompatActivity() {

    var text_email: TextView?=null
    var email:EditText?=null
    var text_mobile:TextView?=null
    var text_91:EditText?=null
    var text_phn:EditText?=null
    var check:CheckBox?=null
    var I_Agree:TextView?=null
    var Amount_Payable:TextView?=null
    var textView:TextView?=null
    var img_view:ImageView?=null
    var text_amount:TextView?=null
   // var btn_back:Button?=null
    var list: ListView?=null
    private fun Validate() :Boolean {
        var found:Boolean=true

        if (!(this.email!!.text.toString().matches("[A-Za-z0-9.-_]+@[a-zA-Z]+\\.[a-zA-Z]{2,4}".toRegex())) && found == true) {
            Toast.makeText(this, "Error: Email ID is missing or Invalid !!!", Toast.LENGTH_LONG).show()
            found = false
        }
        if (!(this.text_mobile!!.text.toString().matches("[1-9][0-9]{9}".toRegex()))) {
            Toast.makeText(this, "Error: Mobile Number is missing or Invalid!!!", Toast.LENGTH_LONG).show()
            found = false
        }

        if ((!(check!!.isChecked))) {
            Toast.makeText(this, "Please agree the terms and conditions!!!",Toast.LENGTH_LONG).show()
            found = false
        }
        return found
    }

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                val intent = Intent(this, Screen1Activity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_booking -> {

                val intent: Intent = Intent(this, BookingHistoryActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.Help -> {
                val intent = Intent(this, HelpActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.aboutUs -> {
                val intentAbout = Intent(applicationContext, AboutUsActivity::class.java)
                startActivity(intentAbout)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen7)
        email=findViewById(R.id.email)
        text_mobile=findViewById(R.id.text_phn)
        check=findViewById(R.id.check)

        val navigation = findViewById<View>(R.id.navigation) as BottomNavigationView
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        list = findViewById<ListView>(R.id.list)

        var dm = data_screen7()
        var arraylist = ArrayList<data_screen7>()

       arraylist.add(data_screen7("Credit Card"))
       arraylist.add(data_screen7("Debit Card"))
       arraylist.add(data_screen7("Cash Card"))
       arraylist.add(data_screen7("Net banking"))
       arraylist.add(data_screen7("Gift Cards"))


        list!!.adapter = CustomAdapter2(arraylist, this)
        text_amount = findViewById<TextView>(R.id.text_amount)


        var user_gold = intent.getIntExtra("value",0);
        var user_silver = intent.getIntExtra("value2",0)
        var user_bronze = intent.getIntExtra("value3",0)
        var movieName=intent.getStringExtra("movieName")
        var theatreName=intent.getStringExtra("theatreName")
        var Timing =intent.getStringExtra("Timing")
        var totalTickets=intent.getIntExtra("tickets",0)
        email=findViewById(R.id.email)
        var amount_gold:Int = 0
       if(user_gold>=0) {
            amount_gold = user_gold * 350
        }else{
            amount_gold =  0
        }

        var amount_silver:Int = 0
        if(user_silver>=0) {
            amount_silver = user_silver * 300
        }
        else{
            amount_silver =  0
        }

        var amount_bronze:Int = 0
        if(user_bronze>=0) {
            amount_bronze = user_bronze * 250
        }
        else{
            amount_bronze =  0

        }

        var total_amount = amount_gold + amount_silver + amount_bronze
        text_amount!!.text = "${total_amount}"

        list!!.setOnItemClickListener { adapterView, view, i, l ->
            val sharedpref=getSharedPreferences("Booking", Context.MODE_PRIVATE)
            val editor=sharedpref.edit()
            editor.putString("Email",email!!.text.toString())
            editor.putString("Movie Name",movieName)
            editor.putString("Theatre Name",theatreName)
            editor.putString("Timing",Timing)
            editor.putInt("Tickets",totalTickets)
            editor.putString("Amount",text_amount!!.text.toString())
            editor.commit()

            //val bundle = this.getIntent().getExtras()
           // val picture = bundle!!.getInt("picture")
            //var emailsend:String=email!!.text.toString()
            if(Validate()) {
                var builder = AlertDialog.Builder(this@Screen7Activity)
                builder.setTitle("Booking Status")
                builder.setMessage("Your Booking is confirmed")
                builder.setPositiveButton("OK") { dialog, which ->
                    val intent:Intent=Intent(this,BookingHistoryActivity::class.java)
                   /* intent.putExtra("email",emailsend)
                    intent.putExtra("movie",movieName)
                    intent.putExtra("theatre",theatreName)
                    intent.putExtra("noftickets",totalTickets)
                    intent.putExtra("timing",Timing)
                    intent.putExtra("picture",picture)*/
                    BookingHistoryActivity.start++;
                    startActivity(intent)
                }
                val dialog: AlertDialog = builder.create()
                dialog.show()
            }
            else
            {
                Toast.makeText(this,"All fields are mandatory",Toast.LENGTH_LONG).show()
            }

        }


    }
}

