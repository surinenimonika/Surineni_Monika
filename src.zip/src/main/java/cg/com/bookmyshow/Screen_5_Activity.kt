package cg.com.bookmyshow

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.view.MenuItem
import android.view.View
import android.widget.*

class Screen_5_Activity : AppCompatActivity() {

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                val intent = Intent(this, Screen1Activity::class.java);
                startActivity(intent);
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_booking ->

            {

                //mTextMessage.setText("Booking History");
                val intent: Intent = Intent(this, BookingHistoryActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.Help -> {
                val intent = Intent(this, HelpActivity::class.java)
                startActivity(intent)
                //mTextMessage.setText("Help");
                return@OnNavigationItemSelectedListener true
            }
            R.id.aboutUs -> {
                val intentAbout = Intent(applicationContext, AboutUsActivity::class.java)
                startActivity(intentAbout)
                // mTextMessage.setText("About Us");
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    var img_plus: ImageButton? = null
    var img_minus: ImageButton? = null
    var text_noOfTickets: TextView? = null
    var text_noOfTickets2: TextView? = null
    var text_noOfTickets3: TextView? = null
    var img_plus2: ImageButton? = null
    var img_minus2: ImageButton? = null
    var img_plus3: ImageButton? = null
    var img_minus3: ImageButton? = null
    var btn_proceed:Button? = null
    var theatreName:TextView?=null
    var Timing:TextView?=null
    var movie1:TextView?=null
   // var btn_back:Button? = null



    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen_5_)
        val navigation = findViewById<View>(R.id.navigation) as BottomNavigationView
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
       // btn_back=findViewById<Button>(R.id.btn_back)
        btn_proceed = findViewById<Button>(R.id.btn_proceed)
        img_plus = findViewById<ImageButton>(R.id.img_plus)
        text_noOfTickets = findViewById<TextView>(R.id.text_noOfTic)
        img_minus = findViewById<ImageButton>(R.id.img_minus)
        img_plus2 = findViewById<ImageButton>(R.id.img_plus2)
        img_minus2 = findViewById<ImageButton>(R.id.img_minus2)

        img_plus3 = findViewById<ImageButton>(R.id.img_plus3)
        img_minus3 = findViewById<ImageButton>(R.id.img_minus3)
        theatreName=findViewById<TextView>(R.id.text_line2)
        Timing=findViewById<TextView>(R.id.text_line3)
        movie1=findViewById<TextView>(R.id.text_line1)

         var movie = intent.getStringExtra("movie")
        movie1!!.setText(movie)
        var theatrename=intent.getStringExtra("Theatrename")
        var timing=intent.getStringExtra("Timing")
        theatreName!!.setText(theatrename)
        Timing!!.setText(timing)
        var minteger: Int = 0
        var flag:Boolean=false;
        var flag2:Boolean=false;
        var flag3:Boolean=false;
        img_plus!!.setOnClickListener {
            flag=true
            minteger = minteger + 1
            text_noOfTickets = findViewById<TextView>(R.id.text_noOfTic)

            if(minteger!!.toString().toInt()>=0)
            {
                text_noOfTickets!!.setText(minteger.toString())
            }
            else
            {
                text_noOfTickets!!.setText(0)
            }

        }
        img_minus!!.setOnClickListener {
            flag=true
            if(minteger>0)
            minteger = minteger - 1
            else
                minteger=0
            text_noOfTickets = findViewById<TextView>(R.id.text_noOfTic)
            if(text_noOfTickets!!.text.toString().toInt()>=0)
            {
                text_noOfTickets!!.setText(minteger.toString())
            }
            else
            {
                text_noOfTickets!!.setText(0)
            }
        }

            var minteger2: Int = 0

            img_plus2!!.setOnClickListener {
                flag2=true
                minteger2 = minteger2 + 1

                text_noOfTickets2 = findViewById<TextView>(R.id.text_noOfTic2)
                if(text_noOfTickets2!!.text.toString().toInt()>=0)
                {
                    text_noOfTickets2!!.setText(minteger2.toString())
                }
                else
                {
                    text_noOfTickets2!!.setText(0)
                }

            }
            img_minus2!!.setOnClickListener {
                flag2=true
                if(minteger2>0)
                minteger2 = minteger2 - 1
                else
                    minteger2=0
                text_noOfTickets2 = findViewById<TextView>(R.id.text_noOfTic2)
                if(text_noOfTickets2!!.text.toString().toInt()>=0)
                {
                    text_noOfTickets2!!.setText(minteger2.toString())
                }
                else
                {
                    text_noOfTickets2!!.setText(0)
                }

            }

        var minteger3: Int = 0

        img_plus3!!.setOnClickListener {
            flag3=true
            minteger3 = minteger3 + 1
            text_noOfTickets3 = findViewById<TextView>(R.id.text_noOfTic3)
            if(text_noOfTickets3!!.text.toString().toInt()>=0)
            {
                text_noOfTickets3!!.setText(minteger3.toString())
            }
            else {
                text_noOfTickets3!!.setText(0)
            }
        }
        img_minus3!!.setOnClickListener {
            flag3=true
            if(minteger3>0)
            minteger3 = minteger3 - 1
            else
                minteger3=0
            text_noOfTickets3 = findViewById<TextView>(R.id.text_noOfTic3)
            if(text_noOfTickets3!!.text.toString().toInt()>=0)
            {
                text_noOfTickets3!!.setText(minteger3.toString())
            }
            else {
                text_noOfTickets3!!.setText(0)
            }
        }
        btn_proceed!!.setOnClickListener {

            val bundle = this.getIntent().getExtras()
            val picture = bundle!!.getInt("picture")
            var intent = Intent(this, Screen7Activity::class.java)
            intent.putExtra("movieName",movie1!!.text.toString())
            intent.putExtra("theatreName",theatreName!!.text.toString())
            intent.putExtra("Timing",Timing!!.text.toString())
            var totalTickets = minteger+minteger2+minteger3
            intent.putExtra("tickets",totalTickets)
            intent.putExtra("picture",picture)
            //val user = null
            if (flag==true) {
                intent.putExtra("value", minteger)
            }
            if(flag2==true){
                intent.putExtra("value2", minteger2)
            }
            if(flag3==true){
                intent.putExtra("value3", minteger3)
            }
            if(minteger<=10 && minteger2<=10 && minteger3<=10 && minteger+minteger2+minteger3<=10&&!( minteger+minteger2+minteger3==0))
            {
                startActivity(intent)
            }
            else {

                Toast.makeText(this, "Minimum one ticket and maximum Ten Tickets for one booking", Toast.LENGTH_LONG).show();
            }
        }

        }

    }



