package cg.com.bookmyshow;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.CalendarView;

public class CalendarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);
        CalendarView calender= findViewById(R.id.calendarView);
        calender.setMinDate(System.currentTimeMillis());

        calender.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {
            @Override
            public void onSelectedDayChange(@NonNull CalendarView calendarView, int i, int i1, int i2) {
                String calenderDate=i2+"/"+(i1+1)+"/"+i;
                Intent intent=new Intent(getApplicationContext(),TheatreScreen.class);
                intent.putExtra("Date",calenderDate);
                String moviename=getIntent().getStringExtra("moviename");
                intent.putExtra("moviename",moviename);
                startActivity(intent);
            }
        });
    }
}
