package cg.com.bookmyshow

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.view.MenuItem
import android.view.View
import com.synnapps.carouselview.CarouselView
import com.synnapps.carouselview.ImageListener
import kotlinx.android.synthetic.main.activity_screen1.*

class ArtsandTheatreActivity : AppCompatActivity() {
    var carouselView: CarouselView?=null

    internal var sampleImages = intArrayOf(R.drawable.arts1, R.drawable.arts2, R.drawable.arts3, R.drawable.arts4)

    internal var imageListener: ImageListener = ImageListener { position, imageView -> imageView.setImageResource(sampleImages[position]) }
    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                val intent = Intent(applicationContext, Screen1Activity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_booking ->


            {

                //mTextMessage.setText("Booking History");
                val intent: Intent = Intent(this, BookingHistoryActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.Help -> {
                val intenthelp = Intent(applicationContext, HelpActivity::class.java)
                startActivity(intenthelp)

                return@OnNavigationItemSelectedListener true
            }
            R.id.aboutUs -> {
                val intenthelp = Intent(applicationContext, AboutUsActivity::class.java)
                startActivity(intenthelp)

                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_artsand_theatre)
        val navigation = findViewById<View>(R.id.navigation) as BottomNavigationView
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)
        layoutInflater.inflate(R.layout.activity_events, container, false)
        carouselView = findViewById(R.id.carouselView)
        carouselView!!.setPageCount(sampleImages.size)
        carouselView!!.setImageListener(imageListener)
    }
}
