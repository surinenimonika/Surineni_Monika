package cg.com.bookmyshow;


import android.os.Parcel;
import android.os.Parcelable;

public class data_screen7 implements Parcelable {

    private String type;

    data_screen7(){

    }

    public String getType() {
        return type;
    }

    public data_screen7(String type) {
        this.type = type;
    }

    public void setType(String type) {
        this.type = type;
    }

    protected data_screen7(Parcel in) {
        type = in.readString();
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(type);
    }

    @SuppressWarnings("unused")
    public static final Creator<data_screen7> CREATOR = new Creator<data_screen7>() {
        @Override
        public data_screen7 createFromParcel(Parcel in) {
            return new data_screen7(in);
        }

        @Override
        public data_screen7[] newArray(int size) {
            return new data_screen7[size];
        }
    };
}