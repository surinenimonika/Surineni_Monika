package cg.com.bookmyshow;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageButton;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by trainee on 8/16/2018.
 */

public class CustomAdapter2 extends ArrayAdapter<data_screen7> {

    public CustomAdapter2(ArrayList<data_screen7> data, Context context) {
        super(context, R.layout.list,data);
    }

    public static class ViewHolder{

        TextView textView;
        ImageButton img_click;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        data_screen7 dm1= getItem(position);

        ViewHolder viewHolder;
        final View result;
        if(convertView==null) {
            viewHolder = new ViewHolder();

            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.list, parent, false);


            viewHolder.textView = (TextView) convertView.findViewById(R.id.textView) ;


            result = convertView;
            convertView.setTag(viewHolder);
        }
        else{
            viewHolder = (ViewHolder)convertView.getTag();
            result = convertView;

        }

        viewHolder.textView.setText(dm1.getType());
        //viewHolder.txtLikes.setText(dm1.getLikes());

        return convertView;
    }
}



