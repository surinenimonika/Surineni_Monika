package cg.com.bookmyshow;

/**
 * Created by trainee on 8/13/2018.
 */

public class MovieDataModel {
private int movieId;
    private String movieName;
    private String Genere;
    private String Language;
    private String length;
    private String Actors;

    public MovieDataModel(String movieName, String genere, String language, String length, String actors) {
        this.movieName = movieName;
        Genere = genere;
        Language = language;
        this.length = length;
        Actors = actors;
    }

    public MovieDataModel() {
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public void setGenere(String genere) {
        Genere = genere;
    }

    public void setLanguage(String language) {
        Language = language;
    }

    public void setLength(String length) {
        this.length = length;
    }

    public void setActors(String actors) {
        Actors = actors;
    }

    public int getMovieId() {
        return movieId;
    }

    public void setMovieId(int movieId) {
        this.movieId = movieId;
    }

    public String getMovieName() {
        return movieName;
    }

    public String getGenere() {
        return Genere;
    }

    public String getLanguage() {
        return Language;
    }

    public String getLength() {
        return length;
    }

    public String getActors() {
        return Actors;
    }


}
