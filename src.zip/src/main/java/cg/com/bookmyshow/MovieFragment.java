package cg.com.bookmyshow;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/**
 * Created by trainee on 8/13/2018.
 */

public class MovieFragment extends android.support.v4.app.Fragment {

    //varribles declared globally
    EditText search;

    int flag=0;
    Intent intent;
    String area="";
    public MovieFragment(){


        listView = null;
    }
    Collection<MovieDataModel>moviel;
    ListView listView;
    MyMovieAdapter movieAdapter;
    ArrayList<MovieDataModel> movielist=new ArrayList<>();
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment

        DatabaseMovies movie = new DatabaseMovies(getContext());

        Map<Integer,MovieDataModel> map = new HashMap<Integer, MovieDataModel>();
        map=movie.retriveAll();
        setHasOptionsMenu(true);
        movie.open();
        View v= inflater.inflate(R.layout.moviefragment, container, false);
        listView=(ListView)v.findViewById(R.id.listview);
        moviel=map.values();

        movieAdapter= new MyMovieAdapter( movielist,getActivity());


        //  movielist.add(new MovieDataModel("RA.One (2D) (U)","Hindi","ActionDrama","2hrs 30min","SharukhKhan"));

        movielist.addAll(moviel);


        search= (EditText)v.findViewById(R.id.search);

        // Capture Text in EditText
        search.addTextChangedListener(new TextWatcher() {

            @Override
            public void afterTextChanged(Editable arg0) {
                // TODO Auto-generated method stub
                String text = search.getText().toString().toLowerCase(Locale.getDefault());
                movieAdapter.filter(text);
            }

            @Override
            public void beforeTextChanged(CharSequence arg0, int arg1,
                                          int arg2, int arg3) {
                // TODO Auto-generated method stub
            }

            @Override
            public void onTextChanged(CharSequence arg0, int arg1, int arg2,
                                      int arg3) {
                // TODO Auto-generated method stub
            }
        });




        listView.setAdapter(movieAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                intent=new Intent(getContext(),TheatreScreen.class);

                TextView moviename=view.findViewById(R.id.moviename);
               // ImageView image=view.findViewById(R.id.imageView);
                String movie=moviename.getText().toString();
                //listView.getItemAtPosition(position);
                Bundle bundle=new Bundle();
                bundle.putInt("image",(R.id.imageView));
                intent.putExtra("moviename",movie);
                intent.putExtra("flag",flag);
                startActivity(intent);
            }
        });
        return v;


    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);
        inflater.inflate(R.menu.menu,menu);


    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {

        int id=item.getItemId();
        if(id==R.id.action_location)
        {
            if(item.getTitle().equals("Mumbai Western"))
            {
                //Area Locaation added
                item.setTitle("Mumbai Eastern");
                flag++;
                area= (String) item.getTitle();
                Toast.makeText(getContext(),""+ flag+"", Toast.LENGTH_SHORT).show();
                // intent.putExtra("area","Eastern");
                movielist.removeAll(moviel);
                movielist.add(new MovieDataModel("The Little Mermaid (2D)","Crime","English","3hrs 00min","Kamal Haasan"));
                movielist.add(new MovieDataModel("Gudachari (2D) (U)","Action","Telugu","3hrs 10min","Adivi sesh"));
                movielist.add(new MovieDataModel("RA.One (2D) (U)","ActionDrama","Hindi","2hrs 30min","SharukhKhan"));
                movielist.add(new MovieDataModel("Infinity War (3D)","action","English","2hrs 30min","RoberDowney Junior"));
               movielist.add(new MovieDataModel("Gold (2D)","drama","Hindi","2hrs 30min","Ranbir Kapoor"));
               movielist.add(new MovieDataModel("parmanu (2D)","Drama","Hindi","2hrs 30min","John Abraham"));
               movielist.add(new MovieDataModel("Inside Out (2D)","Comedy","English","2hrs 30min","Vijay Devarkonda"));
               movielist.add(new MovieDataModel("Satyameva Jayate (2D)","Thriller","Hindi","2hrs 45min","John Abraham"));
               movielist.add(new MovieDataModel("Pari (2D)","Thriller","Hindi","2hrs 20min","vicky Kaushal"));
              movielist.add(new MovieDataModel("ShatamanamBhavati","Drama","Hindi","2hrs 20min","Shashank Khaitan"));
               listView.setAdapter(movieAdapter);

            }else
            {
                item.setTitle("Mumbai Western");
                flag--;
                movielist.remove(0);
                //  movielist.remove(new MovieDataModel("RA.One (2D) (U)","Hindi","ActionDrama","2hrs 30min","SharukhKhan"));
                movielist.addAll(moviel);

                listView.setAdapter(movieAdapter);

            }
        }
        return super.onOptionsItemSelected(item);
    }
}
