package cg.com.bookmyshow;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by trainee on 8/17/2018.
 */

public class DatabaseThetareEastern extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "theatreastern.db";
    public static String DATABASE_TABLE = "TheatreE";
    private SQLiteDatabase database;
    public static String col_moviename = "moviename";
    private static String col_theatrename = "theatrename";
    private static String col_timing1 = "timing1";
    private static String col_timing2 = "timing2";
    private static String col_timing3 = "timing3";
    private static String col_timing4 = "timing4";
    private static String col_timing5 = "timing5";
    private static String col_timing6 = "timing6";

    private String[] columns = {col_moviename,col_theatrename,col_timing1,col_timing2,col_timing3,col_timing4,col_timing5,col_timing6};
    private String selection;
    private String[] selectionArgs;
    private String groupBy;
    private String having;
    private String orderBy;
    public Context context;

    private static final String DATABASE_CREATE = " create table if not exists " + DATABASE_TABLE +
            " ( " + col_moviename + " varchar(15), " + col_theatrename +
            " varchar(15) , " + col_timing1 + " varchar(15) UNIQUE, " + col_timing2 + " varchar(15), "
            + col_timing3 + " varchar(15), " + col_timing4 + " varchar(15)," + col_timing5 + " varchar(15), " + col_timing6 + " varchar(15));";

    public DatabaseThetareEastern(Context context)
    {

        super(context,DATABASE_NAME,null,DATABASE_VERSION);
        this.context = context;

    }
    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL(DATABASE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL(DATABASE_NAME);
        onCreate(sqLiteDatabase);
    }
    public void open()
    {

        database=this.getWritableDatabase();
        //database = context.getApplicationContext().openOrCreateDatabase("fsdf",10,DATABASE_NAME)
        Log.d("SQLITE DEMO","Data base opened");
    }
    public void close()
    {
        database.close();
        Log.d("SQLITE DEMO","Data base closed");
    }

    public long insert(String movieName,String theatreName,String timing1,String timing2,String timing3,String timing4,String timing5, String timing6)
    {
        database=this.getWritableDatabase();
        ContentValues initialvalues = new ContentValues();
        initialvalues.put(col_moviename,movieName);
        initialvalues.put(col_theatrename,theatreName);
        initialvalues.put(col_timing1,timing1);
        initialvalues.put(col_timing2,timing2);
        initialvalues.put(col_timing3,timing3);
        initialvalues.put(col_timing4,timing4);
        initialvalues.put(col_timing5,timing5);
        initialvalues.put(col_timing6,timing6);
        long returnValue = database.insert(DATABASE_TABLE,null,initialvalues);
        if(returnValue>0){
            Log.d("sql",movieName);
            Log.d("SQLITE DEMO","VALUE INSERTED");
        }else
            Log.d("SQLITE DEMO","VALUE NOT INSERTED");
        return returnValue;
    }
    public Map<String,TheatreDataModel> retriveAll(String movieName)
    {
        Map<String,TheatreDataModel> map = new HashMap<String, TheatreDataModel>();
        database = this.getReadableDatabase();
        //Cursor cursor1 = database.query(DATABASE_TABLE, columns, selection, selectionArgs, groupBy, having, orderBy);
        Cursor cursor1 = database.query(DATABASE_TABLE, columns,col_moviename+"=?", new String[] {movieName}, null, null, null);
        if(cursor1.moveToFirst()){
            do{
                TheatreDataModel data = new TheatreDataModel();
                data.setTheatrename(cursor1.getString(cursor1.getColumnIndex(col_theatrename)));
                data.setTiming1(cursor1.getString(cursor1.getColumnIndex(col_timing1)));
                data.setTiming2(cursor1.getString(cursor1.getColumnIndex(col_timing2)));
                data.setTiming3(cursor1.getString(cursor1.getColumnIndex(col_timing3)));
                data.setTiming4(cursor1.getString(cursor1.getColumnIndex(col_timing4)));
                data.setTiming5(cursor1.getString(cursor1.getColumnIndex(col_timing5)));
                data.setTiming6(cursor1.getString(cursor1.getColumnIndex(col_timing6)));
                map.put(data.getTiming1(),data);

            }while (cursor1.moveToNext());

        }
        Log.d("SQLiteDemo-retriveall()", "Record count : ");
        return map;

    }
}
