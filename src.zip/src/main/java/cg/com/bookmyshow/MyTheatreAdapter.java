package cg.com.bookmyshow;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by trainee on 8/14/2018.
 */

public class MyTheatreAdapter extends ArrayAdapter<TheatreDataModel> {

    private ArrayList<TheatreDataModel> arrayList;
    private Context context;

    public MyTheatreAdapter(ArrayList<TheatreDataModel> data, Context context){
        super(context, R.layout.theatre_row,data);
        this.arrayList=data;
        this.context=context;

    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {



        TheatreDataModel dataModel=getItem(position);
        MyTheatreAdapter.ViewHolder viewHolder;

        if(convertView==null)
        {
            viewHolder=new MyTheatreAdapter.ViewHolder();
            LayoutInflater inflater=LayoutInflater.from(getContext());
            convertView=inflater.inflate(R.layout.theatre_row,parent,false);

            viewHolder.movie_name=(TextView)convertView.findViewById(R.id.textView3);
            viewHolder.timing1=(TextView)convertView.findViewById(R.id.textView13);
            viewHolder.timing2=(TextView)convertView.findViewById(R.id.textView14);
            viewHolder.timing3=(TextView)convertView.findViewById(R.id.textView15);
            viewHolder.timing4=(TextView)convertView.findViewById(R.id.textView16);
            viewHolder.timing5=(TextView)convertView.findViewById(R.id.textView17);
            viewHolder.timing6=(TextView)convertView.findViewById(R.id.textView18);

            //result=convertView;
            convertView.setTag(viewHolder);
        }else{
            viewHolder=(ViewHolder) convertView.getTag();
            // result=convertView;
        }


        viewHolder.movie_name.setText(dataModel.getMoviename());
        viewHolder.timing1.setText(dataModel.getTiming1());
        viewHolder.timing2.setText(dataModel.getTiming2());
        viewHolder.timing3.setText(dataModel.getTiming3());
        viewHolder.timing4.setText(dataModel.getTiming4());
        viewHolder.timing5.setText(dataModel.getTiming5());
        viewHolder.timing6.setText(dataModel.getTiming6());



        return convertView;

    }

    private static class ViewHolder
    {
        TextView movie_name;
        TextView timing1;
        TextView timing2;
        TextView timing3;
        TextView timing4;
        TextView timing5;
        TextView timing6;

    }
}

