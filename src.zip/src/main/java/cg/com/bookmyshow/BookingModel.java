package cg.com.bookmyshow;

/**
 * Created by trainee on 8/18/2018.
 */

public class BookingModel
{
    private String movieName;
    public BookingModel(){}

    public BookingModel(String movieName, String theatreName, String time, int tickets, String amount) {
        this.movieName = movieName;
        this.theatreName = theatreName;
        this.time = time;
        this.tickets = tickets;
        this.amount = amount;
    }

    private String theatreName;
    private String time;

    public String getMovieName() {
        return movieName;
    }

    public void setMovieName(String movieName) {
        this.movieName = movieName;
    }

    public String getTheatreName() {
        return theatreName;
    }

    public void setTheatreName(String theatreName) {
        this.theatreName = theatreName;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public int getTickets() {
        return tickets;
    }

    public void setTickets(int tickets) {
        this.tickets = tickets;
    }

    public String getAmount() {
        return amount;
    }

    public void setAmount(String amount) {
        this.amount = amount;
    }

    private int tickets;
    private String amount;
}
