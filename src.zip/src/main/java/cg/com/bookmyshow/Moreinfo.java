package cg.com.bookmyshow;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;

/**
 * Created by trainee on 8/18/2018.
 */

public class Moreinfo  extends android.support.v4.app.Fragment {

    public Moreinfo() {

    }

    TextView moviename;
    TextView info;
    RatingBar rating;
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.moreinfo, container, false);
        moviename=v.findViewById(R.id.textmoviename);
        rating=v.findViewById(R.id.ratingBar);
        info=v.findViewById(R.id.textView6);
        final String intent_moviename=getActivity().getIntent().getStringExtra("moviename");
        moviename.setText(intent_moviename);
        get_json();
        return v;

    }

    public void get_json() {

    String json;
        try {
                InputStream is = getActivity().getAssets().open("info.json");
                int size=is.available();
                byte[] buffer=new byte[size];
                is.read(buffer);
                is.close();
                json=new String(buffer,"UTF-8");
            JSONArray jsonArray=new JSONArray(json);
            for(int i=0;i<jsonArray.length();i++)
            {
                JSONObject obj=jsonArray.getJSONObject(i);
                if(obj.getString("movie").equalsIgnoreCase(moviename.getText().toString()))
                {
                   //Toast.makeText(getContext(),obj.getString("info"),Toast.LENGTH_SHORT).show();
                   info.setText(obj.getString("info"));
                   rating.setRating((float)obj.getDouble("rating"));
                   rating.setIsIndicator(true);
                }

            }


        }
        catch (IOException e)
        {
            e.printStackTrace();
        }
        catch (JSONException y)
        {
            y.printStackTrace();
        }
    }
}