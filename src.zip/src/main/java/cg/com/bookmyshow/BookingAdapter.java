package cg.com.bookmyshow;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by trainee on 8/18/2018.
 */

public class BookingAdapter extends ArrayAdapter<BookingModel> {
    Context context;

    public BookingAdapter(ArrayList<BookingModel> list, Context context) {
        super(context, R.layout.activity_booking_history, list);
        this.context = context;
    }

    private static class ViewHolder {
        TextView movieName;
        TextView theatreName;
        TextView time;
        TextView tickets;
        TextView amount;
        ImageView poster;

    }

    @Nullable
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup
            parent) {
        BookingModel datamodel = getItem(position);
        ViewHolder viewHolder;
        final View result;
        if (convertView == null) {
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.booking_history, parent, false);

            viewHolder.movieName = (TextView) convertView.findViewById(R.id.movieNameBuk);
            viewHolder.theatreName = (TextView) convertView.findViewById(R.id.theatreNameBuk);
            viewHolder.time = (TextView) convertView.findViewById(R.id.timeBuk);
            viewHolder.tickets = (TextView) convertView.findViewById(R.id.ticketsBuk);
            viewHolder.amount = (TextView) convertView.findViewById(R.id.amountBuk);

            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.ic_launcher_background);
            viewHolder.poster = (ImageView) convertView.findViewById(R.id.imagehist);


            result = convertView;
            convertView.setTag(viewHolder);
        } else {
            viewHolder = (ViewHolder) convertView.getTag();
            result = convertView;
        }
        viewHolder.movieName.setText(datamodel.getMovieName());
        viewHolder.theatreName.setText(datamodel.getTheatreName());
        viewHolder.time.setText(datamodel.getTime());
        viewHolder.tickets.setText(""+ datamodel.getTickets());
        viewHolder.amount.setText(datamodel.getAmount());
        if(viewHolder.movieName.getText().equals("RA.One (2D) (U)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imagehist);
            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.raone);

        }
        if(viewHolder.movieName.getText().equals("Gudachari (2D) (U)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imagehist);
            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.gudachari);

        }
        if(viewHolder.movieName.getText().equals("Infinity War (3D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imagehist);
            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.avengers);

        }
        if(viewHolder.movieName.getText().equals("Gold (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imagehist);
            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.gold);

        }
        if(viewHolder.movieName.getText().equals("parmanu (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imagehist);
            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.parmanu2);

        }
        if(viewHolder.movieName.getText().equals("Inside Out (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imagehist);
            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.inout);

        }
        if(viewHolder.movieName.getText().equals("Satyameva Jayate (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imagehist);
            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.satya);

        }
        if(viewHolder.movieName.getText().equals("The Little Mermaid (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imagehist);
            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.merm);

        }
        if(viewHolder.movieName.getText().equals("Pari (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imagehist);
            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.pari);

        }
        if(viewHolder.movieName.getText().equals("ShatamanamBhavati"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imagehist);
            ImageView img=convertView.findViewById(R.id.imagehist);
            img.setImageResource(R.drawable.shatamanam);

        }
        
        return convertView;
    }
}

