package cg.com.bookmyshow;

import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.synnapps.carouselview.CarouselView;
import com.synnapps.carouselview.ImageListener;

/**
 * Created by trainee on 8/13/2018.
 */

public class CinemaFragment extends Fragment {
    CarouselView carouselView;

    int[] sampleImages = {R.drawable.satya, R.drawable.gudachari, R.drawable.inout,R.drawable.parmanu2,R.drawable.pari,R.drawable.merm,R.drawable.gold,R.drawable.avengers};

    ImageListener imageListener = new ImageListener() {
        @Override
        public void setImageForPosition(int position, ImageView imageView) {
            imageView.setImageResource(sampleImages[position]);
        }
    };
    public CinemaFragment(){

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View v = inflater.inflate(R.layout.cinemafragment, container, false);
        carouselView = (CarouselView)v.findViewById(R.id.carouselView);
        carouselView.setPageCount(sampleImages.length);
        carouselView.setImageListener(imageListener);


        return v;
    }

}

