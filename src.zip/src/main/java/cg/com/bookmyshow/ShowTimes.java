package cg.com.bookmyshow;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.DrawableRes;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.ArrayList;

/**
 * Created by trainee on 8/14/2018.
 */

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.ListView;
import android.widget.PopupMenu;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * Created by trainee on 8/13/2018.
 */

public class ShowTimes  extends android.support.v4.app.Fragment {
    TextView movie_name;
    TextView datechanged;
    ArrayList<TheatreDataModel> theatreArray;
    public ShowTimes(){


    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        //final PopupWindow mPopupWindow = null;

        View v= inflater.inflate(R.layout.showtimes, container, false);
        final ListView listView=(ListView)v.findViewById(R.id.listview);
        Button changeDate= v.findViewById(R.id.date);
        datechanged=v.findViewById(R.id.datechanged);
        final TextView date=v.findViewById(R.id.datechanged);
        final String getDate=getActivity().getIntent().getStringExtra("Date");
        final String intent_moviename=getActivity().getIntent().getStringExtra("moviename");
        movie_name=v.findViewById(R.id.movie_name);
        movie_name.setText(intent_moviename);
        int area=getActivity().getIntent().getIntExtra("flag",0);
        Bundle bundle=getActivity().getIntent().getExtras();
       final int picture=bundle.getInt("image");
        DatabaseThetareEastern theatreEastern = new DatabaseThetareEastern(getContext());

        DatabaseTheatre theatreList=new DatabaseTheatre(getContext());
        Map<String,TheatreDataModel> theatreMap = new HashMap<String, TheatreDataModel>();
        if(area==0) {
            theatreList.insert("Gudachari (2D) (U)", "PVR Cinemas", "8:00", "10:00", "12:00", "14:00", "16:00", "18:00");
            theatreList.insert("Gudachari (2D) (U)", "INOX", "8:05", "10:00", "12:00", "14:00", "16:00", "18:15");
            theatreList.insert("Gudachari (2D) (U)", "Movie Planet", "8:10", "10:00", "12:00", "14:00", "16:00", "19:00");
            theatreList.insert("Gudachari (2D) (U)", "Cinepolis", "8:15", "10:00", "12:00", "14:00", "16:00", "18:00");
            theatreList.insert("Gudachari (2D) (U)", "Carnival", "8:20", "10:00", "12:00", "14:00", "16:00", "18:00");
            theatreList.insert("Infinity War (3D)", "PVR Cinemas", "8:01", "10:30", "12:10", "14:30", "16:20", "18:30");
            theatreList.insert("Infinity War (3D)", "INOX", "8:06", "10:30", "12:10", "14:30", "16:20", "18:30");
            theatreList.insert("Infinity War (3D)", "Movie Planet", "8:11", "10:30", "12:30", "14:30", "16:20", "18:30");
            theatreList.insert("Infinity War (3D)", "Cinepolis", "8:16", "10:30", "12:30", "14:30", "16:20", "18:30");
            theatreList.insert("RA.One (2D) (U)", "Cinepolis", "8:19", "10:30", "12:30", "14:30", "16:20", "18:30");
            theatreList.insert("Gold (2D)","PVR Cinemas","8:02","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("Gold (2D)","Carnival","8:03","10:30","12:30","14:30","16:30","18:30");
           theatreList.insert("The Little Mermaid (2D)","Cinepolis","9:00","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("The Little Mermaid (2D)","Movie Planet","9:01","10:30","12:30","14:30","16:30","18:30");
           theatreList.insert("parmanu (2D)","Movie Planet","8:07","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("parmanu (2D)","Cinepolis","9:05","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("Inside Out (2D)","Carnival","9:10","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("Inside Out (2D)","Cinepolis","9:06","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("Satyameva Jayate (2D)","Movie Planet","9:15","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("Satyameva Jayate (2D)","PVR Cinemas","9:20","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("Pari (2D)","Cinepolis","9:16","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("Pari (2D)","PVR Cinemas","9:21","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("ShatamanamBhavati","Movie Planet","9:17","10:30","12:30","14:30","16:30","18:30");
            theatreList.insert("ShatamanamBhavati","PVR Cinemas","9:22","10:30","12:30","14:30","16:30","18:30");

            theatreMap = theatreList.retriveAll(intent_moviename);
            theatreArray = new ArrayList<>();
            Collection<TheatreDataModel> theatre = theatreMap.values();
            theatreArray.addAll(theatre);
            final MyTheatreAdapter theatreAdapter= new MyTheatreAdapter(theatreArray,getActivity());

            listView.setAdapter(theatreAdapter);
        }
        else
        {
            theatreEastern.insert("Gudachari (2D) (U)", "FunSquare Theatre", "8:00", "10:00", "12:00", "14:00", "16:00", "18:00");
            theatreEastern.insert("Gudachari (2D) (U)", "INOX korum", "8:05", "10:00", "12:00", "14:00", "16:00", "18:15");
            theatreEastern.insert("Gudachari (2D) (U)", "R Adlabs", "8:10", "10:00", "12:00", "14:00", "16:00", "19:00");
            theatreEastern.insert("Gudachari (2D) (U)", "Cinemax Wondermall", "8:15", "10:00", "12:00", "14:00", "16:00", "18:00");
            //theatreEastern.insert("Gudachari (2D) (U)", "Carnival", "8:20am", "10:00am", "12:00pm", "2:00pm", "4:00pm", "6:00pm");
            theatreEastern.insert("Infinity War (3D)", "R Adlabs", "8:01", "10:30", "12:10", "14:30", "16:20", "18:30");
            theatreEastern.insert("Infinity War (3D)", "INOX korum", "8:06", "10:30", "12:10", "14:30", "16:20", "18:30");
            theatreEastern.insert("Infinity War (3D)", "Cinemax Wondermall", "8:11", "10:30", "12:30", "14:30", "16:20", "18:30");
            //theatreEastern.insert("Infinity War (3D)", "Cinepolis", "8:16am", "10:30am", "12:30pm", "2:30pm", "4:20pm", "6:30pm");
            //theatreEastern.insert("Infinity War (3D)", "FunSquare Theatre", "8:21am", "10:30am", "12:10pm", "2:30pm", "4:20pm", "6:30pm");
            theatreEastern.insert("RA.One (2D) (U)", "FunSquare Theatre", "8:19", "10:30", "12:10", "14:30", "16:20", "18:30");
            theatreEastern.insert("RA.One (2D) (U)", "INOX korum", "8:19", "10:30", "12:10", "14:30", "16:20", "18:30");
            theatreEastern.insert("Gold (2D)","R Adlabs","8:02","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Gold (2D)","FunSquare Theatre","8:03","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Gold (2D)","INOX korum","8:04","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("The Little Mermaid (2D)","FunSquare Theatre","9:00","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("The Little Mermaid (2D)","Suncity","9:01","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("parmanu (2D)","Suncity","8:07","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("parmanu (2D)","FunSquare Theatre","9:00","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("parmanu (2D)","R Adlabs","9:05","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Inside Out (2D)","Suncity","9:10","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Inside Out (2D)","FunSquare Theatre","9:06","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Inside Out (2D)","R Adlabs","9:11","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Inside Out (2D)","INOX korum","9:07","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Inside Out (2D)","Cinemax Wondermall","9:08","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Satyameva Jayate (2D)","Cinemax Wondermall","9:15","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Satyameva Jayate (2D)","INOX korum","9:20","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Pari (2D)","FunSquare Theatre","9:16","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("Pari (2D)","INOX korum","9:21","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("ShatamanamBhavati","FunSquare Theatre","9:17","10:30","12:30","14:30","16:30","18:30");
            theatreEastern.insert("ShatamanamBhavati","Cinemax Wondermall","9:22","10:30","12:30","14:30","16:30","18:30");

            theatreMap = theatreEastern.retriveAll(intent_moviename);
            theatreArray = new ArrayList<>();
            Collection<TheatreDataModel> theatre = theatreMap.values();
            theatreArray.addAll(theatre);
            final MyTheatreAdapter theatreAdapter= new MyTheatreAdapter(theatreArray,getActivity());

            listView.setAdapter(theatreAdapter);
        }
        if(getDate!=null)
        {
            date.setText(getDate);
        }
        changeDate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                Intent intent=new Intent(getContext(),CalendarActivity.class);
                intent.putExtra("moviename",intent_moviename);
                startActivity(intent);

            }
        });

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, final View view, int i, long l) {

                final Intent intent=new Intent(getActivity(),Screen_5_Activity.class);

                TextView movieName=view.findViewById(R.id.movie_name);
                final  TextView one = (TextView) view.findViewById(R.id.textView13);
                final  TextView two = (TextView) view.findViewById(R.id.textView14);

                final  TextView three = (TextView) view.findViewById(R.id.textView15);
                final  TextView four = (TextView) view.findViewById(R.id.textView16);
                final  TextView five = (TextView) view.findViewById(R.id.textView17);
                final  TextView six= (TextView) view.findViewById(R.id.textView18);
                final PopupMenu popupMenu=new PopupMenu(getActivity(),listView,Gravity.CENTER);
                String datetoday=getDate.substring(0,2);
                LocalDate curr=LocalDate.now();
                int curr1=curr.getDayOfMonth();
                String curr2=String.valueOf(curr1);
                if(curr2.equals(datetoday)) {
                    Toast.makeText(getContext(), "date" + datetoday + curr1, Toast.LENGTH_SHORT).show();
                    Date dt = new Date();
                    int hours = dt.getHours();
                    int minutes = dt.getMinutes();
                    String currentDateTimeString = hours + ":" + minutes;
                    String one1 = one.getText().toString();
                    Toast.makeText(getContext(), "date" + one1 + currentDateTimeString, Toast.LENGTH_SHORT).show();
                    String two2 = two.getText().toString();
                    String three3 = three.getText().toString();
                    String four4 = four.getText().toString();
                    String five5 = five.getText().toString();
                    String six6 = six.getText().toString();
                    popupMenu.getMenuInflater().inflate(R.menu.popup_menu, popupMenu.getMenu());
                    SimpleDateFormat sdf = new SimpleDateFormat("HH:mm");


                    try {
                        Date d1 = sdf.parse(currentDateTimeString);
                        Date d2 = sdf.parse(one1);

                        Date d3 = sdf.parse(two2);
                        Date d4 = sdf.parse(three3);
                        Date d5 = sdf.parse(four4);
                        Date d6 = sdf.parse(five5);
                        Date d7 = sdf.parse(six6);

                        long elapsed1 = d2.getTime() - d1.getTime();

                        if (elapsed1 > 0) {
                            popupMenu.getMenu().add(one1).setIcon(R.drawable.timing);
                        }/* else {
                            Toast.makeText(getContext(), "elapsed" + elapsed1, Toast.LENGTH_SHORT).show();
                        }*/
                        long elapsed2 = d3.getTime() - d1.getTime();
                        if (elapsed2 > 0) {
                            popupMenu.getMenu().add(two2).setIcon(R.drawable.timing);
                        } /*else {
                            Toast.makeText(getContext(), "elapsed" + elapsed2, Toast.LENGTH_SHORT).show();
                        }*/
                        long elapsed3 = d4.getTime() - d1.getTime();
                        if (elapsed3 > 0) {
                            popupMenu.getMenu().add(three3).setIcon(R.drawable.timing);
                        } /*else {
                            Toast.makeText(getContext(), "elapsed" + elapsed3, Toast.LENGTH_SHORT).show();
                        }*/
                        long elapsed4 = d5.getTime() - d1.getTime();
                        if (elapsed4 > 0) {
                            popupMenu.getMenu().add(four4).setIcon(R.drawable.timing);
                        }
                        long elapsed5 = d6.getTime() - d1.getTime();
                        if (elapsed5 > 0) {
                            popupMenu.getMenu().add(five5).setIcon(R.drawable.timing);
                        }
                        long elapsed6 = d7.getTime() - d1.getTime();
                        if (elapsed6 > 0) {
                            popupMenu.getMenu().add(six6).setIcon(R.drawable.timing);
                        }
                    } catch (ParseException e) {
                        e.printStackTrace();
                    }
                }
                else
                {
                    popupMenu.getMenu().add(one.getText().toString()).setIcon(R.drawable.timing);
                    popupMenu.getMenu().add(two.getText().toString());
                    popupMenu.getMenu().add(three.getText().toString());
                    popupMenu.getMenu().add(four.getText().toString());
                    popupMenu.getMenu().add(five.getText().toString());
                    popupMenu.getMenu().add(six.getText().toString());
                }


                final TextView thname=view.findViewById(R.id.textView3);
                popupMenu.setOnMenuItemClickListener(new PopupMenu.OnMenuItemClickListener() {

                    public boolean onMenuItemClick(MenuItem item) {
                        // mPopupWindow.showAtLocation(view,Gravity.BOTTOM,0,0);
                        intent.putExtra("movie",movie_name.getText().toString());
                        intent.putExtra("Timing",item.getTitle());
                        intent.putExtra("Theatrename",thname.getText().toString());
                        intent.putExtra("picture",picture);
                        if(datechanged.getText().toString()=="")
                        {
                            Toast.makeText(getContext(),"Please select date",Toast.LENGTH_SHORT).show();
                        }
                        else
                            startActivity(intent);
                        //Toast.makeText(getActivity(),"You Clicked : " + item.getTitle(), Toast.LENGTH_SHORT).show();
                        return true;
                    }
                });

                popupMenu.show();//showing popup menu

            }
        });




        return v;

    }
}


