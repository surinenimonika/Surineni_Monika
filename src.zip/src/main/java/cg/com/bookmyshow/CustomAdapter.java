package cg.com.bookmyshow;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by trainee on 8/11/2018.
 */

public class CustomAdapter extends ArrayAdapter<Screen1Info> {
    Context context ;
    public CustomAdapter(ArrayList<Screen1Info> list, Context context) {
        super(context, R.layout.screen1,list);
        this.context = context;
    }

    private static class ViewHolder{
        ImageView icon;
        TextView text;
        ImageView rightArrow;

    }
    @Nullable
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup
            parent) {
        Screen1Info datamodel = getItem(position);
        ViewHolder viewHolder;
        final View result;
        if(convertView == null){
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.screen1,parent,false);

            viewHolder.text = (TextView) convertView.findViewById(R.id.text);
            viewHolder.rightArrow = (ImageView) convertView.findViewById(R.id.rightArrow);
            ImageView img=convertView.findViewById(R.id.icon1);
            img.setImageResource(R.drawable.ic_launcher_background);
            viewHolder.icon = (ImageView)convertView.findViewById(R.id.icon1);
            result = convertView;
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder)convertView.getTag();
            result=convertView;
        }
        viewHolder.text.setText(datamodel.getText());
        if(viewHolder.text.getText().equals("MOVIES"))
        {
            viewHolder.icon=(ImageView)convertView.findViewById(R.id.icon1);
            ImageView img=convertView.findViewById(R.id.icon1);
            img.setImageResource(R.drawable.movies);

        }
        if(viewHolder.text.getText().equals("ARTS & THEATRE"))
        {
            viewHolder.icon=(ImageView)convertView.findViewById(R.id.icon1);
            ImageView img=convertView.findViewById(R.id.icon1);
            img.setImageResource(R.drawable.artsicon);

        }
        if(viewHolder.text.getText().equals("SPORTS"))
        {
            viewHolder.icon=(ImageView)convertView.findViewById(R.id.icon1);
            ImageView img=convertView.findViewById(R.id.icon1);
            img.setImageResource(R.drawable.sports);

        }
        if(viewHolder.text.getText().equals("EVENTS"))
        {
            viewHolder.icon=(ImageView)convertView.findViewById(R.id.icon1);
            ImageView img=convertView.findViewById(R.id.icon1);
            img.setImageResource(R.drawable.events);

        }
        return convertView;

    }


}
