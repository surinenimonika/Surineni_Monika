package cg.com.bookmyshow;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Created by trainee on 8/13/2018.
 */

public class MyMovieAdapter extends ArrayAdapter<MovieDataModel> {

    private ArrayList<MovieDataModel> dataset;
    private ArrayList<MovieDataModel> moviedataSet;
    private Context context;
    public MyMovieAdapter(ArrayList<MovieDataModel> data, Context context) {
        super(context,R.layout.movie_row,data);
        this.dataset=data;
        this.context=context;
        this.moviedataSet=new ArrayList<MovieDataModel>();
        this.moviedataSet=data;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {

        MovieDataModel dataModel=getItem(position);
        ViewHolder viewHolder;
        final View result;
        if(convertView==null)
        {
            viewHolder=new ViewHolder();
            LayoutInflater inflater=LayoutInflater.from(getContext());
            convertView=inflater.inflate(R.layout.movie_row,parent,false);
            viewHolder.movie_name=(TextView)convertView.findViewById(R.id.moviename);
            viewHolder.length=(TextView)convertView.findViewById(R.id.lengthtext);
            viewHolder.language=(TextView)convertView.findViewById(R.id.languagetext);
            viewHolder.genere=(TextView)convertView.findViewById(R.id.generetext);
            viewHolder.actors=(TextView)convertView.findViewById(R.id.actoretext);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.ic_launcher_background);
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            result=convertView;
            convertView.setTag(viewHolder);
        }
        else
        {
            viewHolder=(ViewHolder)convertView.getTag();
        }
        viewHolder.movie_name.setText(dataModel.getMovieName());
        viewHolder.length.setText(dataModel.getLength());
        viewHolder.language.setText(dataModel.getLanguage());
        viewHolder.genere.setText(dataModel.getGenere());
        viewHolder.actors.setText(dataModel.getActors());
        if(viewHolder.movie_name.getText().equals("RA.One (2D) (U)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.raone);

        }
        if(viewHolder.movie_name.getText().equals("Gudachari (2D) (U)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.gudachari);

        }
        if(viewHolder.movie_name.getText().equals("Infinity War (3D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.avengers);

        }
        if(viewHolder.movie_name.getText().equals("Gold (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.gold);

        }
        if(viewHolder.movie_name.getText().equals("parmanu (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.parmanu2);

        }
        if(viewHolder.movie_name.getText().equals("Inside Out (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.inout);

        }
        if(viewHolder.movie_name.getText().equals("Satyameva Jayate (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.satya);

        }
        if(viewHolder.movie_name.getText().equals("The Little Mermaid (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.merm);

        }
        if(viewHolder.movie_name.getText().equals("Pari (2D)"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.pari);

        }
        if(viewHolder.movie_name.getText().equals("ShatamanamBhavati"))
        {
            viewHolder.poster=(ImageView)convertView.findViewById(R.id.imageView);
            ImageView img=convertView.findViewById(R.id.imageView);
            img.setImageResource(R.drawable.shatamanam);

        }



        return convertView;

        //return super.getView(position, convertView, parent);
    }
    public void filter(String charText) {
        charText = charText.toLowerCase(Locale.getDefault());
        moviedataSet= (ArrayList<MovieDataModel>) dataset.clone();
       /* Toast.makeText(getContext(),"outside"+moviedataSet.size(),Toast.LENGTH_SHORT).show();
        Toast.makeText(getContext(),"outside datasert"+dataset.size(),Toast.LENGTH_SHORT).show();*/
        dataset.clear();
        /*Toast.makeText(getContext(),"outside datasert"+dataset.size(),Toast.LENGTH_SHORT).show();
        Toast.makeText(getContext(),"outside movidatasert"+moviedataSet.size(),Toast.LENGTH_SHORT).show();
*/
        if (charText.length() == 0) {
           // moviedataSet= (ArrayList<MovieDataModel>) dataset.clone();
            dataset.addAll(moviedataSet);

            Toast.makeText(getContext(),"inif"+dataset.size(),Toast.LENGTH_SHORT).show();
        } else {

            for (MovieDataModel mdm : moviedataSet) {

                if (mdm.getMovieName().toLowerCase(Locale.getDefault()).contains(charText)) {
                    dataset.add(mdm);
                }
            }
        }
        notifyDataSetChanged();
    }
    private static class ViewHolder
    {
        TextView movie_name;
        TextView length;
        TextView genere;
        TextView language;
        TextView actors;
        ImageView poster;
    }
}

