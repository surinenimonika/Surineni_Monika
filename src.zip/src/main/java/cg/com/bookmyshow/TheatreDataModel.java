package cg.com.bookmyshow;

/**
 * Created by trainee on 8/13/2018.
 */

public class TheatreDataModel {

    private String theatrename="";
    private String timing1;
    private String timing2;

    public TheatreDataModel(String theatrename, String timing1, String timing2, String timing3, String timing4, String timing5, String timing6) {
        this.theatrename = theatrename;
        this.timing1 = timing1;
        this.timing2 = timing2;
        this.timing3 = timing3;
        this.timing4 = timing4;
        this.timing5 = timing5;
        this.timing6 = timing6;
    }

    private String timing3;
    private String timing4;
    private String timing5;
    private String timing6;

    public TheatreDataModel() {
    }

    public void setTheatrename(String theatrename) {
        this.theatrename = theatrename;
    }

    public void setTiming1(String timing1) {
        this.timing1 = timing1;
    }

    public void setTiming2(String timing2) {
        this.timing2 = timing2;
    }

    public void setTiming3(String timing3) {
        this.timing3 = timing3;
    }

    public void setTiming4(String timing4) {
        this.timing4 = timing4;
    }

    public void setTiming5(String timing5) {
        this.timing5 = timing5;
    }

    public void setTiming6(String timing6) {
        this.timing6 = timing6;
    }

    public String getMoviename() {
        return theatrename;
    }

    public String getTiming1() {
        return timing1;
    }

    public String getTiming2() {
        return timing2;
    }

    public String getTiming3() {
        return timing3;
    }

    public String getTiming4() {
        return timing4;
    }

    public String getTiming5() {
        return timing5;
    }

    public String getTiming6() {
        return timing6;
    }
}
