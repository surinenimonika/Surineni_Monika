package cg.com.bookmyshow;

import android.media.Image;
import android.widget.ImageView;

/**
 * Created by trainee on 8/11/2018.
 */

public class Screen1Info {

    private Image icon;
    private String text;

    public Screen1Info(String text) {
        this.text = text;
    }

    public Image getIcon() {
        return icon;
    }

    public void setIcon(Image icon) {
        this.icon = icon;
    }

    public String getText() {
        return text;
    }

    public void setText(String text) {
        this.text = text;
    }

    public ImageView getRightarrow() {
        return rightarrow;
    }

    public void setRightarrow(ImageView rightarrow) {
        this.rightarrow = rightarrow;
    }

    private ImageView rightarrow;
}

