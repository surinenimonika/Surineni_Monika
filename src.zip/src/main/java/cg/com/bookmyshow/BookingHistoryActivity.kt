package cg.com.bookmyshow

import android.content.Context
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.BottomNavigationView
import android.view.View
import android.widget.ImageView
import android.widget.ListView
import android.widget.TextView
import kotlinx.android.synthetic.main.activity_booking_history.*
import kotlinx.android.synthetic.main.activity_screen7.*

class BookingHistoryActivity : AppCompatActivity() {

    companion object {
        var start = 0;

    }

    private val mOnNavigationItemSelectedListener = BottomNavigationView.OnNavigationItemSelectedListener { item ->
        when (item.itemId) {
            R.id.navigation_home -> {
                val intent = Intent(this, Screen1Activity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.navigation_booking -> {
                val intent: Intent = Intent(this, BookingHistoryActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.Help -> {
                val intent = Intent(this, HelpActivity::class.java)
                startActivity(intent)
                return@OnNavigationItemSelectedListener true
            }
            R.id.aboutUs ->

            {
                val intentAbout = Intent(applicationContext, AboutUsActivity::class.java)
                startActivity(intentAbout)
                return@OnNavigationItemSelectedListener true
            }
        }
        false
    }

    var bukingList: ArrayList<BookingModel> = ArrayList<BookingModel>()
    var list: ListView?=null
    var imagepic:ImageView?=null;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_booking_history)

        val navigation = findViewById<View>(R.id.navigation) as BottomNavigationView
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener)


        if (start >0) {
            val bookingDetails = getSharedPreferences("Booking", Context.MODE_PRIVATE)
            val movieName = bookingDetails.getString("Movie Name", "")
            //  val email = bookingDetails.getString("Email", "")
            val theatreName = bookingDetails.getString("Theatre Name", "")
            val timing = bookingDetails.getString("Timing", "")
            val totalTickets = bookingDetails.getInt("Tickets", 0)
            val amount = bookingDetails.getString("Amount", "")
            list= findViewById(R.id.bukList)
            //val bundle = this.getIntent().getExtras()
           // val picture = bundle!!.getInt("picture")

            bukingList.add(BookingModel(movieName, theatreName, timing, totalTickets, amount))

            list!!.adapter = BookingAdapter(bukingList, this)

        }

        else
        {


        }
        }
    }

