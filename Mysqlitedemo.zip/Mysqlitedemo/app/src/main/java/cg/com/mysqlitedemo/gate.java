package cg.com.mysqlitedemo;
import android.content.Context;
import android.location.Address;
import android.location.Geocoder;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.maps.model.LatLng;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class gate {

    //For getting the GeoCoded location for an address
    public static List<LatLng> getLatLongFromAddress(String address, Context context) {

        List<LatLng> listLatLong = new ArrayList<>();
        if (Geocoder.isPresent()) {
            try {
                Geocoder geocoder = new Geocoder(context, Locale.getDefault());
                List<Address> addresses = geocoder.getFromLocationName(address, 3); // get the found Address Objects

                listLatLong = new ArrayList<LatLng>(addresses.size()); // A list to save the coordinates if they are available
                for (Address a : addresses) {
                    if (a.hasLatitude() && a.hasLongitude()) {
                        listLatLong.add(new LatLng(a.getLatitude(), a.getLongitude()));
                    }
                }
            } catch (IOException e) {
                // handle the exception
                Log.e("TAG", ""+e.getMessage());
            }
        }
        //Log.d("TAG", "listLatLong.size()-->" + listLatLong.size());
        return listLatLong;
    }

    //For getting the Address from a Latitude and Longitude object
    public static String getAddressFromLatLong(double latitude, double longitude, Context context) {
        String strAdd = "";
        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
        try {
            List<Address> addresses = geocoder.getFromLocation(latitude, longitude, 3);
            if (addresses != null) {
                Address returnedAddress = addresses.get(0);
                StringBuilder strReturnedAddress = new StringBuilder("");

                for (int i = 0; i <= returnedAddress.getMaxAddressLineIndex(); i++) {
                    strReturnedAddress.append(returnedAddress.getAddressLine(i)).append("\n");
                }
                strAdd = strReturnedAddress.toString();
                //Log.d("LOG", strReturnedAddress.toString());
            } else {
                Toast.makeText(context, "No Address returned", Toast.LENGTH_LONG).show();
            }
        } catch (Exception e) {
            Toast.makeText(context, "Could not get Address. Error is" + e.getMessage(), Toast.LENGTH_LONG).show();
        }
        return strAdd;
    }
}