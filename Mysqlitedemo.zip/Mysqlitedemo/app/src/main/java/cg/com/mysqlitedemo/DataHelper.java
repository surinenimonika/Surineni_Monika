package cg.com.mysqlitedemo;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by trainee on 7/26/2018.
 */

public class DataHelper extends SQLiteOpenHelper {
public static final String TABLE_NAME="employee";
public static final int DATABASE_VERSION=1;
public static final String DATABASE_NAME="emp.db";
    private SQLiteDatabase database;
    EmployeeBean bean = new EmployeeBean();
    public static String col_id = "id";
    private static String col_name = "name";
    private static String col_age = "age";
    private static String col_sal = "salary";
    private String[] columns = {col_id,col_name,col_age,col_sal};
    private String selection;
    private String[] selectionArgs;
    private String groupBy;
    private String having;
    private String orderBy;
    public Context context;
    private static final String create="create table if not exists " + TABLE_NAME +
            " (" + col_id + " integer primary key autoincrement, " + col_name +
            " varchar(15)," + col_age + " integer, " + col_sal + " integer);";

    public DataHelper(Context context) {
        super(context,DATABASE_NAME,null,DATABASE_VERSION);
        this.context = context;
    }
    public String getCol_name()
    {return col_name;}
    public String getCol_age()
    {return col_age;}
    public String getCol_sal()
    {return col_sal;}
    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL(create);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(DATABASE_NAME);
        onCreate(db);
    }
    public void open(){
        database = this.getWritableDatabase();
        Log.d("SQLITE DEMO","Data base opened");
    }
    public void close(){
        database.close();
        Log.d("SQLITE DEMO","Data base closed");
    }
    public String verify(String searchkey)
    {
        String password="  ";

        Cursor c=database.rawQuery("Select "+col_age+" From "+TABLE_NAME+" where "+col_name+"='"+searchkey+"'",null);
        if(c.getCount()<=0)
        {
            return "No such user exist";

        }
        else if(c.moveToFirst())
        {
            do{
                password=c.getString(c.getColumnIndex(col_age));

            }while(c.moveToNext());
        }
        return password;
    }
    public long insert(String name,String age,String salary){
        ContentValues initialvalues = new ContentValues();
        initialvalues.put(col_name,name);
        initialvalues.put(col_age,Integer.parseInt(age));
        initialvalues.put(col_sal,Integer.parseInt(salary));
        long returnValue = database.insert(TABLE_NAME,null,initialvalues);
        if(returnValue>0){
            Log.d("SQLITE DEMO","VALUE INSERTED");
            Toast.makeText(context,"Inserted",Toast.LENGTH_SHORT).show();
        }else
            Log.d("SQLITE DEMO","VALUE NOT INSERTED");
        return returnValue;
    }
    public int update(ContentValues values,String whereClause,String whereArgs[]){
        int returnValue = database.update(TABLE_NAME,values,whereClause,whereArgs);
        if(returnValue > 0)
        {
            Log.d("SQLITE DEMO","VALUE UPDATED");
        Toast.makeText(context,"updated",Toast.LENGTH_SHORT).show();}
        else
            Log.d("SQLITE DEMO","VALUE NOT UPGRADED");
        return returnValue;
    }
    public int delete(String whereClause,String whereArgs[]){
        int returnValues = database.delete(TABLE_NAME,whereClause,whereArgs);
        if(returnValues > 0)
        {
            Log.d("SQLITE DEMO","VALUE DELETED");
            Toast.makeText(context,"deleted",Toast.LENGTH_SHORT).show();}
        else
            Log.d("SQLITE DEMO","VALUE NOT DELETED");
        return returnValues;
    }
    public Map<Integer,EmployeeBean> retriveAll(){
        Map<Integer,EmployeeBean> map = new HashMap<Integer, EmployeeBean>();
        ///database = this.getReadableDatabase();
        Cursor cursor1 = database.query(TABLE_NAME, columns, selection, selectionArgs, groupBy, having, orderBy);
        if(cursor1.moveToFirst()){
            do{
                EmployeeBean bean = new EmployeeBean();
                bean.setEmp_id(Integer.parseInt(cursor1.getString(cursor1.getColumnIndex(col_id))));
                bean.setName(cursor1.getString(cursor1.getColumnIndex(col_name)));
                bean.setAge(Integer.parseInt(cursor1.getString(cursor1.getColumnIndex(col_age))));
                bean.setSalary(Integer.parseInt(cursor1.getString(cursor1.getColumnIndex(col_sal))));
                map.put(bean.getEmp_id(),bean);
                Toast.makeText(context,map.values().toString(),Toast.LENGTH_LONG).show();
            }while (cursor1.moveToNext());

        }
        Log.d("SQLiteDemo-retriveall()", "Record count : ");
        return map;

    }
    public Map<Integer,EmployeeBean> search(String name)
    {
        String q="Select * from "+TABLE_NAME+" where " + col_name+ "='" +name+"'";
        Cursor cursor1= database.rawQuery(q,null);
        Map<Integer,EmployeeBean> map = new HashMap<Integer, EmployeeBean>();
        if(cursor1.moveToFirst()){
            do{
                EmployeeBean bean = new EmployeeBean();
                bean.setEmp_id(Integer.parseInt(cursor1.getString(cursor1.getColumnIndex(col_id))));
                bean.setName(cursor1.getString(cursor1.getColumnIndex(col_name)));
                bean.setAge(Integer.parseInt(cursor1.getString(cursor1.getColumnIndex(col_age))));
                bean.setSalary(Integer.parseInt(cursor1.getString(cursor1.getColumnIndex(col_sal))));
                map.put(bean.getEmp_id(),bean);
                Toast.makeText(context,map.values().toString(),Toast.LENGTH_LONG).show();
            }while (cursor1.moveToNext());

        }
        return map;


    }

}
