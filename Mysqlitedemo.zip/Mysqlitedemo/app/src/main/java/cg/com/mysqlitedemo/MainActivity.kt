package cg.com.mysqlitedemo

import android.content.ContentValues
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import kotlinx.android.synthetic.main.activity_login.*

class MainActivity : AppCompatActivity() {
    var name: EditText?=null
    var age: EditText?=null
    var updateAge: EditText?=null
    var salary: EditText?=null
    var Insert:Button?=null
    var update:Button?=null
    var viewAll:Button?=null
    var dpHelper = DataHelper(this);
    var sea:Button?=null;
    var searchelement:EditText?=null;
    var m:Button?=null;
    var back:Button?=null
    var bean = EmployeeBean()


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
         name=findViewById(R.id.name)as EditText
        age=findViewById(R.id.age)as EditText
        updateAge=findViewById(R.id.update)as EditText
        salary=findViewById(R.id.salary)as EditText
        Insert=findViewById(R.id.insert)as Button
        update=findViewById(R.id.updatebutton)as Button
        viewAll=findViewById(R.id.show)as Button
        sea=findViewById(R.id.search)as Button
        m=findViewById(R.id.button2)as Button
        back=findViewById(R.id.button4)as Button
        searchelement=findViewById(R.id.searchelement)as EditText
        dpHelper.open()
        Insert!!.setOnClickListener {
           dpHelper.insert(name!!.text.toString(),age!!.text.toString(),salary!!.text.toString())

        }
        update!!.setOnClickListener {
            var updateValues = ContentValues()
            updateValues.put("${dpHelper.getCol_age()}", "${(updateAge!!.text.toString()).toInt()}")
            dpHelper.update(updateValues, "${dpHelper.getCol_name()} = +'${name!!.text.toString()}'", null)
        }
        viewAll!!.setOnClickListener {
       var intent: Intent =Intent(this, ViewActivity::class.java)
            startActivity(intent)

        }
        sea!!.setOnClickListener {
            var intent: Intent =Intent(this, search::class.java)
            intent.putExtra("name",searchelement!!.text.toString())
            startActivity(intent)

        }
        m!!.setOnClickListener {
            var intent: Intent =Intent(this, MapsActivity::class.java)
            startActivity(intent)
        }
        back!!.setOnClickListener {
            var intent: Intent =Intent(this, loginActivity::class.java)
            startActivity(intent)
        }
    }
}
