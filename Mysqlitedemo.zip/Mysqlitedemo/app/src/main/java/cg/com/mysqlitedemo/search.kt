package cg.com.mysqlitedemo

import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView
import android.widget.Toast
import cg.com.mysqlitedemo.DataHelper.col_id

class search : AppCompatActivity() {
    var listView:ListView?=null
    var dbhepler = DataHelper(this)




    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_search)
        var intent = getIntent()
        var name=getIntent().getStringExtra("name")
        dbhepler.open()
        var map =  dbhepler.search(name)
        listView = findViewById(R.id.listView1 ) as ListView
        var arrayList = ArrayList<EmployeeBean>()
        for(i in map){
            arrayList.add(i.value)
        }
        listView!!.adapter = CustomAdapter(arrayList,this)


    }

}
