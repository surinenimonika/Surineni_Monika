package cg.com.mysqlitedemo;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.util.ArrayList;

/**
 * Created by trainee on 7/26/2018.
 */

public class CustomAdapter extends ArrayAdapter<EmployeeBean> {
    Context context;
    public CustomAdapter(ArrayList<EmployeeBean> list,Context context)
    {
        super(context, R.layout.employeerow,list);
        this.context = context;
    }

    private static class ViewHolder{


        TextView emp_age;
        TextView emp_name;
        TextView emp_id;
        TextView emp_sal;

    }
    @Nullable
    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup
            parent) {
        EmployeeBean datamodel = getItem(position);
        ViewHolder viewHolder;
        final View result;
        if(convertView == null){
            viewHolder = new ViewHolder();
            LayoutInflater inflater = LayoutInflater.from(getContext());
            convertView = inflater.inflate(R.layout.employeerow,parent,false);
            viewHolder.emp_age = (TextView) convertView.findViewById(R.id.emp_age);
            viewHolder.emp_name = (TextView)convertView.findViewById(R.id.emp_name);
            viewHolder.emp_id = (TextView) convertView.findViewById(R.id.emp_id);
            viewHolder.emp_sal = (TextView) convertView.findViewById(R.id.emp_sal);
            result = convertView;
            convertView.setTag(viewHolder);
        }else {
            viewHolder = (ViewHolder)convertView.getTag();
            result=convertView;
        }
        Integer emp_id1 =(datamodel.getEmp_id());
        Integer emp_sal1 =(datamodel.getSalary());
        Integer emp_age1 =(datamodel.getAge());
        viewHolder.emp_age.setText(emp_age1.toString());
        viewHolder.emp_name.setText(datamodel.getName());
        viewHolder.emp_id.setText(emp_id1.toString());
        viewHolder.emp_sal.setText(emp_sal1.toString());

        return convertView;

    }


}
