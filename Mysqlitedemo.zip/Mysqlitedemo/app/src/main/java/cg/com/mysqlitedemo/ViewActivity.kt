package cg.com.mysqlitedemo

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.widget.ListView

class ViewActivity : AppCompatActivity() {
var listView:ListView?=null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)
        var dbhepler = DataHelper(this)
        dbhepler.open()
        var map =  dbhepler.retriveAll()
        listView = findViewById(R.id.listView) as ListView
        var arrayList = ArrayList<EmployeeBean>()
        for(i in map){
            arrayList.add(i.value)
        }
        listView!!.adapter = CustomAdapter(arrayList,this)
    }
}
