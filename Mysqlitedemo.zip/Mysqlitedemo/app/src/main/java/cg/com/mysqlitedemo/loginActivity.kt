package cg.com.mysqlitedemo

import android.content.Intent
import android.database.sqlite.SQLiteDatabase
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v7.app.AlertDialog
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import android.content.DialogInterface



class loginActivity : AppCompatActivity(){
 var submit: Button?=null
    var username:EditText?=null
    var password:EditText?=null
    var dbhepler = DataHelper(this)
    var register:Button?=null
    var dialog:AlertDialog?=null
//    private var database: SQLiteDatabase? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

    val builder = AlertDialog.Builder(this)

    builder.setTitle("Yooo...")
    builder.setMessage("login successful")
    dbhepler.open()
     submit=findViewById(R.id.button)as Button
        username=findViewById(R.id.login)as EditText
        password=findViewById(R.id.password)as EditText
        register=findViewById(R.id.button3)as Button
        password!!.setOnFocusChangeListener(){view:View,b:Boolean->
            if(dbhepler.verify(username!!.text.toString())!="No such user exists")
            {
                submit!!.isEnabled=true
                submit!!.setOnClickListener {
                    if(password!!.text.toString()==dbhepler.verify(username!!.text.toString()))
                        builder.setCancelable(false)

                    builder.setPositiveButton("OK") { dialog, which -> Toast.makeText(this, "Ok broo..", Toast.LENGTH_LONG).show() }

                    builder.setNegativeButton("Cancel") { dialog, which -> Toast.makeText(this, "Cancelled", Toast.LENGTH_LONG).show() }

                    val dialog = builder.create()

                    dialog.show()
                    Toast.makeText(this,"login successful",Toast.LENGTH_SHORT).show()
                }
            }
            else
            {
                Toast.makeText(this,"No such user exists",Toast.LENGTH_LONG).show()
            }

        }
          register!!.setOnClickListener {
              var intent: Intent =Intent(this, MainActivity::class.java)
              startActivity(intent)

          }

    }
}
